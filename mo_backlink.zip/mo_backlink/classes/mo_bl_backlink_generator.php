<?php


namespace mo_App;


use mo_App\dashboard_pages\mo_bl_buyer_items;

class mo_bl_backlink_generator
{
    private $buyer_items = object ;
    public function __construct()
    {
        $this->buyer_items = new mo_bl_buyer_items() ;
    }

    public function get_purchased_itemes_sorted_by_site_id(array $purchased_items){
        $results = array() ;
        foreach ($purchased_items as $purchased_item){
            $results [$purchased_item["site_id"]][] = $purchased_item ;
        }

        return $results ;
    }

    public function site_item_validate($item){
        if ($item["start_date"] > time() ){
            echo "خطای تاریخ شروع
            <br>" ;
            return false ;
        }
        if($item["finish_date"] < time()) {
            echo "خطای تاریخ پایان
            <br>" ;
            return false ;
        }
        if($item["confirm"] == 0 OR $item["confirm"] == false){
            //echo "error confirm website<br>" ;
            //return false ;
        }
        $user_id = $item["site_user_id"] ;
        $user_status = get_user_meta($user_id,"user_status",true) ;
        if($user_status != "publish"){
            echo "error confirm user<br>" ;
            return false ;
        }

        $site_status = $item["site_status"] ;
        if($site_status != "publish"){
            echo "error seller site status <br>" ;
            return false ;
        }
        return true ;
    }

    public function generate_back_link_files(){
        $purchased_items = $this->buyer_items->get_purchased_items() ;
        // site id means seller site id actually the site we want generate file for

       // $results["site_id"] = array() ;
        $results = $this->get_purchased_itemes_sorted_by_site_id($purchased_items) ;


        foreach ($results as $sites){
            $sites_item_validate = array() ; //[site_id]["link_of_backlink"]
            foreach ($sites as $item){

                if($this->site_item_validate($item) === true ){

                    $sites_item_validate [ $item["site_id"] ][ $item["link_of_backlink"] ] = $item;

                }else{
                    $site_link = $this->get_site_link_file_name($item["site_link"]) ;
                    if(file_exists(mo_backliknk_backlink_files_dir."/".$site_link.".js")){
                        unlink(mo_backliknk_backlink_files_dir."/".$site_link.".js") ;
                    }

                }
            }

            if ( count($sites_item_validate )  == 0){


                continue ;
            }

            foreach ($sites_item_validate as $site_validate){
                // create content of file

                $file_mid = '<ul>' ;
                foreach ($site_validate as $site_items){
                    $rand = rand(1,21) ;
                    $file_mid .= '<li class="bgcolor'.$rand.'"><a href="'.$site_items["link_of_backlink"] .'" target="_blank" title="'.$site_items["title_of_backlink"] .'" rel="dofollow"><button >'.$site_items["title_of_backlink"] .'</button></a></li>' ;

                }
                //$rand = rand(1,21) ;
                //$file_mid .= '<li class="bgcolor'.$rand.'"><a href="https://buy-backlink.co/" target="_blank" title="خرید بک لینک از بای بک لینکو" rel="dofollow"><button >خرید بک لینک</button></a></li>' ;

                $file_mid .= '</ul>' ;

                $file_start = '<div class="buybacklickco">' ;
                $style = '<style>.bgcolor0{color:#fff;background-color:#a4c400}.bgcolor1{color:#fff;background-color:#60a917}.bgcolor2{color:#fff;background-color:#008a00}.bgcolor3{color:#fff;background-color:#00aba9}.bgcolor4{color:#fff;background-color:#1ba1e2}.bgcolor5{color:#fff;background-color:#3e65ff}.bgcolor6{color:#fff;background-color:#0050ef}.bgcolor7{color:#fff;background-color:#6a00ff}.bgcolor8{color:#fff;background-color:#aa00ff}.bgcolor9{color:#fff;background-color:#f472d0}.bgcolor10{color:#fff;background-color:#d80073}.bgcolor11{color:#fff;background-color:#a20025}.bgcolor12{color:#fff;background-color:#e51400}.bgcolor13{color:#fff;background-color:#fa6800}.bgcolor14{color:#fff;background-color:#f0a30a}.bgcolor15{color:#fff;background-color:#e3c800}.bgcolor16{color:#fff;background-color:#825a2c}.bgcolor17{color:#fff;background-color:#6d8764}.bgcolor18{color:#fff;background-color:#647687}.bgcolor19{color:#fff;background-color:#76608a}.bgcolor20{color:#fff;background-color:#87794e}.bgcolor21{color:#fff;background-color:#a0522d}.buybacklickco ul { list-style-type: none; margin: 0; padding: 0; overflow: hidden; }.buybacklickco li { float: right;}.buybacklickco li a { display: block; color: white; text-align: center; padding: 14px 16px; text-decoration: none;}.buybacklickco li a:hover { background-color: #111;}</style>' ;
                $file_end = '</div>' ;

                $content_of_the_file = "
    document.write( '".$file_start.$style.$file_mid.$file_end .
                    "');


";
                // in here most create a file with seller site title name and add the files into it
               $site_link = $this->get_site_link_file_name($item["site_link"]) ;
                $myfile = fopen(mo_backliknk_backlink_files_dir."/".$site_link.".js", "w") ;
                //var_dump($myfile);
                fwrite($myfile, $content_of_the_file);
                fclose($myfile);


            }




        }




        return $content_of_the_file ;
    }

    public function get_site_link_file_name($site_link){

        $site_link = str_replace("https://","",$site_link) ;
        $site_link = str_replace("http://","",$site_link) ;
        $site_link = str_replace("/","",$site_link) ;

        return $site_link ;
    }
    public function check_script_exist_in_seller_site(){

        $purchased_items = $this->buyer_items->get_purchased_items() ;
        // site id means seller site id actually the site we want generate file for

        // $results["site_id"] = array() ;
        $results = $this->get_purchased_itemes_sorted_by_site_id($purchased_items) ;


        $site_urls = array() ;

        foreach ($results as $sites){

            $sites_item_validate = array() ; //[site_id]["link_of_backlink"]
            foreach ($sites as $item){

                if($this->site_item_validate($item) === true ){

                    $site_ids[] = $item["site_id"] ;
                    //$sites_item_validate [ $item["site_id"] ][ $item["link_of_backlink"] ] = $item;

                }
            }

        }

        if($site_ids != null){
            $site_ids = array_unique($site_ids) ;
        }


        foreach ($site_ids as $site_id){

            $site_url = get_post_meta($site_id,"siteLink",true) ;
            $content = $this->curl_get_file_contents($site_url) ;
            //$content_http = $this->curl_get_file_contents("http://".$site_url)  ;

            $script_found =  str_contains($content, "mo_backlink/backlink_files") ;
            //$script_found_http =  str_contains($content, "mo_backlink/backlink_files") ;

            if(
                $script_found !== true

            ){
                $now = time() ;

                $last_not_found_time = get_post_meta($site_id,"last_script_not_found_time",true) ;
                $script_not_found_counter = get_post_meta($site_id,"script_not_found_counter",true) ;
                echo "<br> for $site_id script not found counter  $script_not_found_counter<br>" ;
                if($last_not_found_time AND ($last_not_found_time > $now-(60*60*24) ) ){

                    $script_not_found_counter = (int)$script_not_found_counter ;
                    $script_not_found_counter++ ;
                    update_post_meta($site_id,"script_not_found_counter",$script_not_found_counter) ;
                }else{
                    update_post_meta($site_id,"script_not_found_counter",1) ;
                }

                update_post_meta($site_id,"last_script_not_found_time",$now) ;

                // afther 3 chain days
                if($script_not_found_counter > 3){
                    echo "<br> for $site_id script not found script counter change to  $script_not_found_counter and disable<br>" ;
                    update_post_meta($site_id,"status","disable") ;
                }

            }else{
                echo "<br> for $site_id script  found <br>" ;
                update_post_meta($site_id,"script_not_found_counter",0) ;
            }

            exit();

        }


    }

    public function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }


}