<?php
namespace mo_App\wordpress_admin_panel ;

use mo_App\mo_bl_notice;

class options
{
    public $notice = object ;
    public function __construct()
    {
        $this->notice = new mo_bl_notice() ;
        if(isset($_POST["submit"])){
            $this->set_options($_POST);
            $this->notice->set_notice("save","تنظیمات با موفقیت ذخیره شد","success") ;

        }
        $this->check_dependencies();
    }
    public function set_options(array $array){
        foreach ($array as $key=>$value){
            if($key == "submit"){
                continue ;
            }
            update_option("$key" , "$value") ;
        }
    }

    public function get_page_url_by_option_name($option){
        $page_id = get_option("$option") ;
        if(is_numeric($page_id)){
            return get_permalink($page_id) ;
        }
        return false ;

    }
    public function check_dependencies(){


        if (! class_exists( 'ACF' ) ) {
            $this->notice->set_notice("dependencies","
               پلاگین acf یا advance_custom_fields  برای درست کار کردن این پلاگین الزامی است ان را از لینک زیر نصب و فعال کنید تا این پیام را نبینید
               </br>
               افزونه را از لینک زیر نصب کنید 
               <a href='https://wordpress.org/plugins/advanced-custom-fields/'>acf advanced costume fields</a> 
","error") ;

        }
}
}