<?php


namespace mo_App;


use mo_App\dashboard_pages\mo_bl_mysites;

class mo_bl_accounting
{
    public $crud = object ;
    public $crud_factor = object ;
    private $user =object ;
    private $mysite =object ;


    public function __construct()
    {
        $this->user = mo_bl_user::get_instance() ;
        $this->crud = new mo_bl_CRUD_post() ;
        $this->crud_factor = new mo_bl_CRUD_post() ;
        $this->mysite = new mo_bl_mysites() ;
    }

    public function add_factor($type="backlink"){
        $title = "فاکتور مشتری". $this->user->get_current_user_display_name() ;
        $meta_fields = array(
          "paid" => 0 ,
          "type" => $type ,
        );
        $factor_id = $this->crud->insert_post($title,"publish",$this->user->user_id(),"mo_bl_factor",$meta_fields) ;
        return $factor_id ;
    }

    public function update_factor(int $factor_id,$meta_fields){

        $this->crud->update_post($factor_id,array(),$meta_fields) ;

    }

    public function factor_paid($factor_id){
        update_post_meta($factor_id,"paid" , 1) ;
    }

    public function add_factor_item($factor_id,$site_id,$price_per_month_seller,$price_per_month_buyer,$number_of_month,$start_date_timestamp,$title_of_backlink,$link_of_backlink,$reportage_file_url="",$type="backlink"){


        $site_link = get_post_meta($site_id, "siteLink", true);

        $meta_fields = array(
          "price_per_month_seller" =>  $price_per_month_seller,
          "price_per_month_buyer" =>  $price_per_month_buyer,
          "number_of_month" =>  $number_of_month,
          "start_date" =>  $start_date_timestamp,
          "factor_id" =>  $factor_id,
          "title_of_backlink" =>  $title_of_backlink,
          "link_of_backlink" =>  $link_of_backlink,
          "site_id" =>  $site_id,
          "confirm" =>  0,
          "reportage_file" =>  $reportage_file_url,
          "type" =>  $type,
        );

        return $this->crud->insert_post($site_link,"publish",$this->user->user_id(),"mo_bl_factor_item",$meta_fields) ;
    }
    public function update_factor_item(){
    //dont need to use
    }
    public function get_site_id_by_item_id($item_id){
        return get_post_meta($item_id,"site_id",true) ;
    }

    /**
     * @param $user_id
     * @param $factor_id
     * @param $type //buy_backling ,withdrawal_cash_from_user ,deposit_cash_from_user ,seller_income
     * @param $status //queue or free
     */
    public function add_accounting_record($user_id,$factor_id,$type,$bede,$bestan,$start_date,$free_date,$factor_item_id,$status){
        $title = "$type : ".$this->user->get_current_user_display_name() ;
        $meta_fields = array(
            "factor_id" => $factor_id ,
            "type" =>$type,
            "bede" =>$bede,
            "bestan" =>$bestan,
            "time" =>time(),
            "start_date" =>$start_date,
            "free_date" =>$free_date,
            "factor_item_id" =>$factor_item_id,
            "status" =>$status,
        );
        $this->crud->insert_post($title,"publish",$user_id,"mo_bl_accounting",$meta_fields) ;

    }


    public function get_factor_items_by_factor_id($factor_id){
        $meta_fields = array(
            'relation' => 'AND',
                array(
                    'key' => 'factor_id',
                    'value' => $factor_id,
                    'compare' => '='
                )
                            ) ;

        $items = $this->crud->get_posts("mo_bl_factor_item",1,-1,array(),array(),$meta_fields) ;
       return $items  ;
    }

    public function get_factor_list($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            /* array(
                 'key' => 'factor_id',
                 'value' => $factor_id,
                 'compare' => '='
             )*/
        ) ;
        $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
        $mainarray = array(
            'order' => 'DESC',
            'orderby' => 'ID',

        ) ;
        if($user_id != 0){
            $mainarray["author"] = $user_id ;
        }
        $items = $this->crud_factor->get_posts("mo_bl_factor",$paged,20,array(),$mainarray,$meta_fields) ;
        return $items  ;
    }
    public function get_paid_factor_list($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
             array(
                 'key' => 'paid',
                 'value' => 1,
                 'compare' => '='
             )
        ) ;
        $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
        $mainarray = array(
            'order' => 'DESC',
            'orderby' => 'ID',

            ) ;
        if($user_id != 0){
            $mainarray["author"] = $user_id ;
        }
        $items = $this->crud_factor->get_posts("mo_bl_factor",$paged,-1,array(),$mainarray,$meta_fields) ;
        return $items  ;
    }

    public function get_buyer_factor_price_by_id($factor_id){
        $items = $this->get_factor_items_by_factor_id($factor_id) ;
        $price = 0 ;
        foreach ($items as $item){
            $bprice = get_post_meta($item->ID,"price_per_month_buyer",true) ;
            $month = get_post_meta($item->ID,"number_of_month",true) ;
            if($month == "reportage"){
                $month = 1 ;
            }
            $price = $price + ($bprice * $month) ;
        }

        return $price ;
    }

    public function get_enqueue_amount($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'type',
                'value' => "seller_income",
                'compare' => '='
            ),
            array('key' => 'free_date',
                'value' => time(),
                'compare' => '>' ,// this is for enquee
                //'compare' => '<' // this is for free
            ),
        ) ;
        if($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bestan",true);

            $result = $result + $amount ;
        }
        return $result ;
    }

    public function get_wallet_plus_free_amount($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            array('relation' => 'OR',
                array('key' => 'type',
                    'value' => "seller_income",
                    'compare' => '='
                ),

                array('key' => 'type',
                    'value' => "user_wallet_charged",
                    'compare' => '='
                ),
            ),


            array('key' => 'free_date',
                'value' => time(),
                //'compare' => '>' ,// this is for enquee
                'compare' => '<' // this is for free
            ),
        ) ;
        if($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bestan",true);

            $result = $result + $amount ;
        }
        return $result ;
    }

    public function get_free_amount($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            array('relation' => 'OR',
                array('key' => 'type',
                    'value' => "seller_income",
                    'compare' => '='
                ),

            ),


            array('key' => 'free_date',
                'value' => time(),
                //'compare' => '>' ,// this is for enquee
                'compare' => '<' // this is for free
            ),
        ) ;
        if($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bestan",true);

            $result = $result + $amount ;
        }
        return $result ;
    }

    public function get_amount_paid($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'type',
                'value' => "withdrawal_cash_from_user", // this means the cash that site pay to user
                'compare' => '='
            ),

        ) ;
        if ($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bede",true);

            $result = $result + $amount ;
        }
        return $result ;
    }


    public function get_amount_paid_by_wallet($user_id=0){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'type',
                'value' => "paid_by_wallet", // this means the cash minus from wallet to paid for backlink
                'compare' => '='
            ),

        ) ;
        if ($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bede",true);

            $result = $result + $amount ;
        }
        return $result ;
    }

    public function get_amount_paid_list(){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'type',
                'value' => "withdrawal_cash_from_user", // this means the cash that site pay to user
                'compare' => '='
            ),

        ) ;

        $args["author"]  = $this->user->user_id() ;
        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        return $accounting_records ;
    }

    public function get_amount_deposit_list(){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'type',
                'value' => "deposit_cash_from_user", // this means the cash that site pay to user
                'compare' => '='
            ),

        ) ;

        $args["author"]  = $this->user->user_id() ;
        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_accounting",1,-1,array(),$args,$meta_fields) ;
        return $accounting_records ;
    }

    public function get_amount_withdrawal_request ($user_id = 0 ){

          $meta_fields = array(
              'relation' => 'AND',
              array('key' => 'deposited',
                  'value' => "0",
                  'compare' => '='
              ),

          ) ;
        if ($user_id != 0 ){
            $args["author"]  = $user_id ;
        }else{
            $args["author"]  = $this->user->user_id() ;
        }

        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_withdraw",1,-1,array(),$args,$meta_fields) ;
        $result = 0 ;
        foreach ($accounting_records as $record){


            $amount = get_post_meta($record->ID,"bede",true);
            if($amount){
                $result = $result + $amount ;
            }

        }
        return $result ;
    }

    public function get_withdrawal_status_by_id($id){
        $deposited = get_post_meta($id,"deposited",true) ;
        if($deposited == 1){
            echo "
            <span class=\"badge bg-success\">
                                   پرداخت شده است         
                                        </span>" ;
        }else{
            echo "
            <span class=\"badge bg-warning\">
                                   در انتظار پرداخت        
                                        </span>" ;
        }
    }
    public function get_withdeawal_requerst_list(){
        $meta_fields = array(
            'relation' => 'AND',
            array('key' => 'deposited',
                'value' => "0",
                'compare' => '='
            ),

        ) ;

        $args["author"]  = $this->user->user_id() ;
        $args["post_status"]  = "publish" ;

        $accounting_records = $this->crud->get_posts("mo_bl_withdraw",1,-1,array(),$args,$meta_fields) ;
        return $accounting_records ;
    }

    public function get_amount_payable($user_id=0){

        return $this->get_wallet_plus_free_amount($user_id) - $this->get_amount_paid_by_wallet($user_id) -  $this->get_amount_paid($user_id) -  $this->get_amount_withdrawal_request() ;
    }

    public function get_rozname_list(){
        $meta_fields = array(
            'relation' => 'AND',


        ) ;

        $args["author"]  = $this->user->user_id() ;
        $args["post_status"]  = "publish" ;
        $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
        $accounting_records = $this->crud->get_posts("mo_bl_accounting",$paged,10,
            array(  'ID' => 'ASC' )
            ,$args,$meta_fields) ;

        return $accounting_records ;
    }

    public function display_pagination(){
        $this->crud->display_pagination();
    }
    public function get_bedeh_user(){
        //mizan bedehkari karbar
    }
    public function get_bestan_user(){
        //mizan bestankari karbar
    }

    public function get_user_assessment(){
        // 4000 bedehkar for example
    }
}