<?php
namespace  mo_App ;

use Gregwar\Captcha\CaptchaBuilder;

class mo_bl_security
{
    public function __construct()
    {

        $this->sesseion_start();
    }

    private $captcha_builder = object ;
    public function sesseion_start() {

        if ($_SESSION == NULL)  {

            if(!headers_sent()){
                session_start() ;
            }

            $_SESSION["set"] = "set" ;
        }
    }


    public function validate_google_captcha(){

            if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])):
                //your site secret key
                $secret = get_option("bl_google_captcha_secret_key");
                //get verify response data

                //var_dump("amirrrrrrrrrrrrr hhhhhhhhhhh");
                $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
                //var_dump($verifyResponse);
                $responseData = json_decode($verifyResponse);
                //var_dump($responseData);
                if($responseData->success):
                    //contact form submission code
                    $name = !empty($_POST['name'])?$_POST['name']:'';
                    $email = !empty($_POST['email'])?$_POST['email']:'';
                    $message = !empty($_POST['message'])?$_POST['message']:'';

                    return true ;

                    $succMsg = 'Your contact request have submitted successfully.';
                else:
                    return false ;
                    $errMsg = 'Robot verification failed, please try again.';
                endif;
            else:
                return false ;
                $errMsg = 'Please click on the reCAPTCHA box.';
            endif;

    }
    public function create_csrf_session(){

       $this->sesseion_start();
       $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    }

    public function check_csrf($input){

        $this->sesseion_start();

        if($_SESSION["csrf_token"] === $input) {
            return true ;
        }
        return false ;
    }

    /**
     * create captcha image
     * @param array classes for html img tag optional
     */

    public function create_captcha_object(){
        $this->captcha_builder  = new CaptchaBuilder();

        return $this->captcha_builder ;
    }

    public function create_captcha_img (array $classes= array()){

        $this->sesseion_start();
        $this->create_captcha_object();
        $this->captcha_builder->build();
        $textclass="" ;
        foreach ($classes as $class){
            $textclass .= " $class " ;
        }
        $_SESSION["phrase"] = $this->captcha_builder->getPhrase();
        echo "<img class=\"".$textclass."\" src=\"".$this->captcha_builder->inline()."\" />" ;

    }

    /** validation_captcha
     * return true if valid and false if not valid
     *
     * @param string $userInput get from the user form
     * @return boolean
     **/
    public function validate_captcha($userInput){
        $this->sesseion_start();
        $userInput == strtolower($userInput) ;
        $_SESSION["phrase"] = strtolower($_SESSION["phrase"]) ;

        if($_SESSION["phrase"] == $userInput) {
            // instructions if user phrase is good

            return true ;
        }
        else {
            // user phrase is wrong
            return false ;
        }
    }

    public function check_user_login(){
        if(is_user_logged_in()){
            return true ;
        }
        return false ;
    }
    public function redirect($url){
        if (!headers_sent()){
            header('Location: '.$url); exit;
        }else{
            echo '<script type="text/javascript">';
            echo 'window.location.href="'.$url.'";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
            echo '</noscript>'; exit;
        }
    }
    public function  check_input($string)
    {


        $search = array(
            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
        );
        $string = preg_replace($search,'',$string);
        $string = trim($string) ;
       $string = htmlspecialchars($string) ;

        return $string;
    }
}