<?php


namespace mo_App;


class mo_bl_email
{
    static function send($to,$subject ,$message){
        $email = "info@buy-backlink.co" ;
        $headers = 'From: buy-backlink.co <'. $email  . ">\r\n" ;
        return wp_mail($to,$subject,$message,$headers) ;
    }

}