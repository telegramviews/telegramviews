<?php


namespace mo_App;

interface mo_bl_gatways_interface{

    public function set_callback($callback_url) ;
    public function set_price($price) ;
    public function set_description($description) ;
    public function set_email($email) ;
    public function set_mobile($mobile) ;
    public function set_name($name) ;
    public function get_name() ;
    /*
     * vaerify payment res most be like
     * array( "status"=>"success" OR "error",
     *  "other_parameters_you_need"=> "anything you want" )
     */
    public function verify_payment() :bool ;
    public function afther_payment_error()  ;
    public function afther_payment_success()   ;
    public function redirect_to_gatways()  ;
}
