<?php


namespace mo_App;


use mo_App\wordpress_admin_panel\options;

class dashboard
{
    public $menu_title = "" ;
    public $group_of_menu = "" ;


    public $options= object ;
    public $route= object ;




    public function __construct()
    {
        $this->option = new options() ;
        $this->route = new routing() ;


        if(! is_user_logged_in()){
            wp_redirect($this->option->get_page_url_by_option_name("bl_login_page_id")) ;
            exit();
        }

        $this->group_of_menu = $this->set_group_of_menu($this->route->page) ;

    }

    public function set_group_of_menu($page){
        $group = "" ;
        if($page == "mysite"){
            $group = "seller" ;
        }
        if($page == "buyer_sites"){
            $group = "buyer" ;
        }
        if($page == "buyer_sites_reportage"){
            $group = "buyer" ;
        }
        if($page == "buyer_factor"){
            $group = "buyer" ;
        }
        if($page == "buyer_items"){
            $group = "buyer" ;
        }
        if($page == "withdrawal_request"){
            $group = "accounting" ;
        }
        if($page == "account_statment"){
            $group = "accounting" ;
        }

        return $group ;
    }
    public function dashboard_construct(){

    }

    /**
     * @param $page_name its page name without .php its can get of the routing->page
     */


    public  function set_title($page_name){
        if($page_name == "index"){
            $title = " داشبورد |".get_bloginfo("name") ;

        }elseif($page_name == "mysite"){
            $title = " سایت های من |".get_bloginfo("name") ;

        }elseif($page_name == "buyer_sites"){
            $title = " خرید بک لینک |".get_bloginfo("name") ;

        }elseif($page_name == "buyer_sites_reportage"){
            $title = " خرید رپورتاژ |".get_bloginfo("name") ;

        }elseif($page_name == "buyer_factor"){
            $title = " فاکتور های شما |".get_bloginfo("name") ;

        }elseif($page_name == "buyer_items"){
            $title = " اقلام خریداری شده |".get_bloginfo("name") ;

        }elseif($page_name == "account_statment"){
            $title = " ریز حساب من |".get_bloginfo("name") ;

        }elseif($page_name == "withdrawal_request"){
            $title = " درخواست برداشت وجه |".get_bloginfo("name") ;

        }elseif($page_name == "deposit_request"){
            $title = " واریز وجه |".get_bloginfo("name") ;

        }elseif($page_name == "user_information"){
            $title = " اطلاعات کاربر |".get_bloginfo("name") ;

        }elseif($page_name == "support"){
            $title = " پشتیبانی |".get_bloginfo("name") ;

        }


        else{
            $title = $page_name ;
        }
        return $title ;
    }

    public function set_headers(){
        // set and echo meta and rels and tags in head
        return ""  ;
    }

    public function set_wrap_page($page){
        return mo_backlink_views_dashboard."/components/main-wrap/".$page.".php" ;
    }

    public function is_active($menu,$page,$group=""){
        if($menu != "" && $menu == $group && $group != ""){
            return true ;
        }
        if($menu == $page){
            return true ;
        }
        return false ;
    }

    public function the_is_active($menu,$page,$group = ""){
        if($this->is_active($menu,$page,$group)){
            return " active " ;
        }else{
            return " " ;
        }
    }

    public function get_url($page){
        $url = $this->option->get_page_url_by_option_name("bl_dashboard_page_id" ) ;
        if($url){
            return $url."?routPage=".$page ;
        }else{
            wp_die("عدم توانایی شناخت ادرس صفحه منو")  ;
        }

    }

    public function display_sort_button($button_name,$column_name){
        $button = "" ;

            if(isset($_GET["$button_name"])){
               $button_value = $_GET[$button_name] ;
               $get_clumn_name_array = explode("-",$button_value) ;
               $get_clumn_name = $get_clumn_name_array [1] ;
            }










        if( isset($_GET["$button_name"]) && $button_value == "DESC-$column_name" ){

            $button = "   <button type=\"submit\" title=\"مرتب سازی نزولی\" class=\"sort_btn\" name=\"$button_name\" value=\"ACS-$column_name\" >
                                        <i class=\"fa fa-sort-desc\" aria-hidden=\"true\"></i>
                                    </button>" ;
        }elseif( isset($_GET["$button_name"]) && $button_value == "ACS-$column_name" ){

            $button = " <button type=\"submit\" title=\"مرتب سازی صعودی\" class=\"sort_btn\" name=\"$button_name\" value=\"DESC-$column_name\" >
                                        <i class=\"fa fa-sort-asc\" aria-hidden=\"true\"></i>
                                    </button>" ;
        }else{
            $button = " <button type=\"submit\" title=\"مرتب سازی صعودی/ نزولی\" class=\"sort_btn\" name=\"$button_name\" value=\"DESC-$column_name\" >
                                        <i class=\"fa fa-sort\" aria-hidden=\"true\"></i>
                                    </button>" ;
        }

        return $button ;
    }


}
