<?php


namespace mo_App\dashboard_pages;


use mo_App\dashboard;
use mo_App\form_validate;
use mo_App\gatways\mo_bl_zarinpal;
use mo_App\mo_bl_accounting;
use mo_App\mo_bl_gatways;
use mo_App\mo_bl_gatways_interface;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;

class mo_bl_deposit_page extends dashboard
{
    public $notice = object ;
    public $security = object ;
    public $formvalidate = object ;
    public $accounting = object ;

    public $user = object ;


    public $inputs = array() ;



    public $verify_price = 0 ;
    public $verify_factor_id = 0 ;
    public $verify_gatway = "" ;

    public $gatways = object ;
    public function __construct()
    {
        $this->gatways = new mo_bl_gatways() ;

        $this->notice= new mo_bl_notice() ;
        $this->security = new mo_bl_security() ;
        $this->formvalidate = new form_validate() ;
        $this->accounting = new mo_bl_accounting() ;
        $this->user = mo_bl_user::get_instance() ;


        if(isset($_GET["price"])){
            $this->verify_price = $_GET["price"]  ;
        }
        if(isset($_GET["factor_id"])){
            $this->verify_factor_id = $_GET["factor_id"]  ;
        }
        if(isset($_GET["gatway"])){
            $this->verify_gatway = $_GET["gatway"]  ;

            $selected_gatway = $this->verify_gatway ;
            $selected_gatway = str_replace("\\"."\\","\\",$selected_gatway) ;
            $selected_gatway= "\\".$selected_gatway ;
            $this->verify_gatway = new $selected_gatway() ;
        }




        if(isset($_POST["adddeposit"])){
            foreach ($_POST as $key=>$value){
                $this->inputs[$key] = $this->security->check_input($value) ;
            }

            if($this->validation()){

                $selected_gatway = $this->inputs["gatway"] ;
                $selected_gatway = str_replace("\\"."\\","\\",$selected_gatway) ;
                $selected_gatway= "\\".$selected_gatway ;
                $selected_gatway = new $selected_gatway() ;


                $price = $this->inputs["amount"] ;

                $this->run_gatway($selected_gatway,
                    "wallet_charge",
                    $price,
                    "waller charge for user ".$this->user->get_current_user_display_name(),
                    $this->user->get_user_mobile(),
                    $this->user->get_user_email()  );
            }
        }




    }

    private function run_gatway(mo_bl_gatways_interface $selected_gatways,$factor_id,$price,$description,$mobile,$email){
        $call_back = new \mo_App\mo_bl_gatways();
        $zarinpal = new \mo_App\gatways\mo_bl_zarinpal() ;
        $call_back->add_gatways($zarinpal);
        $selected_gatways_string = get_class($selected_gatways) ;

        $selected_gatway = $call_back->set_selected_gatway( $selected_gatways ) ;
        $selected_gatway->set_price($price) ;
        $selected_gatway->set_description("$description") ;

        $selected_gatway->set_mobile("$mobile") ;
        $selected_gatway->set_email("$email") ;
        $selected_gatway->set_params(array()) ;
        //var_dump($selected_gatway->data);
        $selected_gatway->set_callback($call_back->callback_url."&factor_id=$factor_id&gatway=$selected_gatways_string&price=$price") ;
        // var_dump($selected_gatway->data) ;
        $selected_gatway->redirect_to_gatways();
        //$selected_gatway->verify_payment();
        $this->notice = $selected_gatway->notice ;
        // wp_die($call_back->callback_url."&factor_id=$factor_id&gatway=$selected_gatways_string&price=$price");
    }

    public function verify_payment($factor_id,$price,mo_bl_gatways_interface $selected_gatway){


        $call_back = new \mo_App\mo_bl_gatways();
        $zarinpal = new \mo_App\gatways\mo_bl_zarinpal() ;
        $call_back->add_gatways($zarinpal);



        $selected_gatway = $call_back->set_selected_gatway( $selected_gatway ) ;
        $selected_gatway->set_price($price) ;
        $selected_gatway->set_callback($call_back->callback_url."&factor_id=$factor_id") ;
        $varify = $selected_gatway->verify_payment();
        $this->notice = $selected_gatway->notice ;

        if($varify == true){ //TODO afther test it is must be true
            $this->afther_verify_success() ;
        }

    }

    public function afther_verify_success(){



        $this->accounting->add_accounting_record($this->user->user_id(),$this->verify_factor_id,"user_wallet_charged",
            0,$this->verify_price,0,0,0,0);


        $this->notice->set_notice("success_payment","پردازش های حسابداری با موفقیت انجام شد  ","success") ;

    }


    public function validation(){
        if( !isset($this->inputs["amount"]) OR $this->formvalidate->is_empty($this->inputs["amount"]) ){
            $this->notice->set_notice("amount","فیلد مقدار باید پر شود ","error") ;
        }
        if(!$this->formvalidate->is_numeric($this->inputs["amount"])){
            $this->notice->set_notice("amount","باید عدد باشد","error") ;
        }




        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;

    }


    public function get_gatways_option(){
        /** if you want add more gatway at first you must create new class in gatway directory
         * then create a object then add your new object to gatways like this
         *   $zarinpal = new mo_bl_zarinpal() ;
         *   $zarinpal->set_name("درگاه زرین پال")  ;
         *   $this->gatways->add_gatways($zarinpal);
         * **/
        $zarinpal = new mo_bl_zarinpal() ;
        $zarinpal->set_name("درگاه زرین پال")  ;
        $this->gatways->add_gatways($zarinpal);


        $this->gatways->get_gatways_list();
    }


}