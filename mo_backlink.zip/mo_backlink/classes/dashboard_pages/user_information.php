<?php


namespace mo_App\dashboard_pages;


use mo_App\dashboard;
use mo_App\form_validate;
use mo_App\mo_bl_CRUD_post;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;

class user_information extends dashboard
{

    public $notice = object ;
    public $user = object ;
    public $form_validate = object ;
    public $security = object ;
    public $croud = object ;


    public $inputs = array() ;
    private $upload_result = array() ; //set value for this parameters in form_validation()

    public function __construct()
    {



        $this->notice = new mo_bl_notice() ;
        $this->user = mo_bl_user::get_instance() ;
        $this->form_validate = new form_validate() ;
        $this->security = new mo_bl_security() ;
        $this->croud = new mo_bl_CRUD_post() ;

        $this->inputs["nameOfUser"] = $this->user->get_current_user_display_name() ;
        $this->inputs["bankName"] = $this->user->get_user_bank_name() ;
        $this->inputs["bankAccountNumber"] = $this->user->get_user_bank_account_number() ;
        $this->inputs["bankAccountShaba"] = $this->user->get_user_bank_account_shaba() ;


        if(isset($_POST["update_user_info"])){
            foreach ($_POST as $key=>$value){
                $this->inputs["$key"] = $this->security->check_input($value) ;
            }

            if($this->form_validation()){
               $this->user_update() ;
               $this->user->update_user_meta($this->inputs);

               if($_FILES["uploadImage"]["name"]!= ""){
                   $this->user->update_user_meta(array(
                       "avatar_url"=> $this->upload_result["img_url"],
                       "user_status"=> "pending"
                   ));
               }


                if( !$this->notice->get_count_notice_by_type("error") >=1){
                    $this->notice->set_notice("success","اطلاعات شما بروز شد و باید به تایید مدیر سایت برسد","success") ;
                }



            }


        }
        $this->security->create_csrf_session();
    }


    public function user_update(){
        $user_result = $this->user->user_update(  array(
            "ID"=>$this->user->user_id() ,
            "first_name" =>$this->inputs["nameOfUser"],
            "display_name" =>$this->inputs["nameOfUser"] )  ) ;
        if(is_wp_error($user_result)){
            $this->notice->set_notice("nameOfUser",$user_result->get_error_message(),"error") ;
        }
    }

    public function display_user_status(){
        $message  = "تایید نشده" ;
        $html_class  = "badge badge-danger" ;
        $status =  $this->user->get_user_status() ;

        if($status == "pending"){
            $message = "در انتظار تایید" ;
            $html_class = "badge badge-warning" ;
        }
        if($status == "publish"){
            $message = "تایید شده" ;
            $html_class = "badge badge-success" ;
        }
        echo "

          <h6>
                    وضعیت اکانت شما :
                    <span class=\"$html_class\">
                               $message
                    </span>

           </h6>
           
        " ;
    }

    private function form_validation(){
        if( ! $this->security->check_csrf($this->inputs["bl_csrf"])){
            $this->notice->set_notice("security","یک خطای امنیتی رخ داده است","error") ;
        }
        if( !$this->form_validate->check_length($this->inputs["nameOfUser"],2,50) ){
            $this->notice->set_notice("nameOfUser","نام باید بین 2 تا 50 کاراکتر باشد","error") ;
        }

        if( $this->form_validate->is_empty($this->inputs["nameOfUser"]) ){
            $this->notice->set_notice("nameOfUser","نام کاربر نباید خالی باشد","error") ;
        }
        if( !$this->form_validate->check_length($this->inputs["bankName"],2,50) ){
            $this->notice->set_notice("bankName","نام بانک باید بین 2 تا 50 کاراکتر باشد","error") ;
        }

        if( !$this->form_validate->check_length($this->inputs["bankAccountNumber"],2,50) ){
            $this->notice->set_notice("bankAccountNumber","شماره حساب بانک باید بین 2 تا 50 کاراکتر باشد","error") ;
        }

        if( !$this->form_validate->check_length($this->inputs["bankAccountShaba"],2,50) ){
            $this->notice->set_notice("bankAccountNumber","شماره شبا بانک باید بین 2 تا 50 کاراکتر باشد","error") ;
        }

        if( !$this->form_validate->is_empty($_FILES ["uploadImage"]["name"])  ){
            $this->upload_result = $this->croud->uplode_pic("uploadImage",$this->user->user_id()) ;
            if($this->upload_result["type"] == "error"){

                $this->notice->set_notice("uploadImage",$this->upload_result["message"],"error") ;
            }
        }

        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;

    }
}