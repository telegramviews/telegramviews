<?php


namespace mo_App\dashboard_pages;


use mo_App\mo_bl_accounting;

class mo_bl_buyer_items
{
    public $accounting = object ;
    public $user = object ;

    public function __construct()
    {
        $this->accounting = new mo_bl_accounting() ;
        $this->user = \mo_App\mo_bl_user::get_instance() ;
    }

    public function get_purchased_items($user_id=0){
        $result = array() ;
        $fatcors = $this->accounting->get_paid_factor_list($user_id) ;
        foreach ($fatcors as $fatcor){

            $items = $this->accounting->get_factor_items_by_factor_id($fatcor->ID) ;
            foreach ($items as $item){
                $price_per_month_seller = get_post_meta($item->ID,"price_per_month_seller",true) ;
                $price_per_month_buyer = get_post_meta($item->ID,"price_per_month_buyer",true) ;
                $number_of_month = get_post_meta($item->ID,"number_of_month",true) ;
                if($number_of_month == "reportage"){
                    $number_of_month = 1 ;
                }
                $start_date_timestamp = get_post_meta($item->ID,"start_date",true) ;
                $factor_id = get_post_meta($item->ID,"factor_id",true) ;
                $title_of_backlink = get_post_meta($item->ID,"title_of_backlink",true) ;
                $link_of_backlink = get_post_meta($item->ID,"link_of_backlink",true) ;
                $site_id = get_post_meta($item->ID,"site_id",true) ;
                $confirm = get_post_meta($item->ID,"confirm",true) ;
                $reportage_url = get_post_meta($item->ID,"reportage_file",true) ;
                $type = get_post_meta($item->ID,"type",true) ;

                $site_post = get_post($site_id) ;
                $finish_date =  $start_date_timestamp + ( (60*60*24*30)*($number_of_month)  );
            $result[] = array(
                "price_per_month_seller" =>  $price_per_month_seller,
                "price_per_month_buyer" =>  $price_per_month_buyer,
                "number_of_month" =>  $number_of_month,
                "start_date" =>  $start_date_timestamp,
                "finish_date" =>  $finish_date,
                "factor_id" =>  $factor_id,
                "title_of_backlink" =>  $title_of_backlink,
                "link_of_backlink" =>  $link_of_backlink,
                "site_id" =>  $site_id,
                "site_status" =>  get_post_meta($site_id,"status",true),
                "site_title" =>  $site_post->post_title,
                "site_link" =>  get_post_meta($site_id,"siteLink",true) ,
                "confirm" =>  $confirm,
                "site_user_id" => $site_post->post_author ,
                "reportage_file" => $reportage_url ,
                "type" => $type ,
            ) ;
            }
        }

        return $result ;
    }

}