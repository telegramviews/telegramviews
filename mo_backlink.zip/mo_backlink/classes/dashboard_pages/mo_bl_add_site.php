<?php


namespace mo_App\dashboard_pages;


use mo_App\dashboard;
use mo_App\form_validate;
use mo_App\mo_bl_CRUD_post;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;

class mo_bl_add_site extends dashboard
{
    public  $security = object ;
    public  $notice = object ;
    public  $form_validate = object ;
    private $CRUD = object ;
    private $user = object ;

    private $csrf = "" ;

    /**
     * @var array
     * site siteName : not be empty
     * site siteLink : without http this not be already exists
     * siteTopic:not empty
     * sitePriceOneMonth : number and not empty
     */
    public $inputs = array() ;

    public function __construct()
    {
        $this->notice = new mo_bl_notice() ;
        $this->security = new mo_bl_security() ;
        $this->form_validate = new form_validate() ;
        $this->CRUD = new mo_bl_CRUD_post() ;
        $this->user = mo_bl_user::get_instance() ;


        if(isset($_POST["addsite"])){


            foreach ($_POST as $key=>$value){

                $this->inputs["$key"] = $this->security->check_input($value) ;
            }
            //  ["reportage_check"]=> string(۲) "on"


            $this->csrf = $this->inputs["bl_csrf"] ;
            $this->inputs["status"] = "pending" ;
            if($this->validate_add_site_form()){
                //insert into database
               $post_id =  $this->CRUD->insert_post($this->inputs["siteName"],"draft",$this->user->user_id(),"mo_bl_sites",$this->inputs) ;
               if($post_id){
                   $this->notice->set_notice("success","سایت شما با موفقیت ثبت شد","success") ;
                   $this->inputs =$this->form_validate->reset_forms($this->inputs);

               }
            }
        }

        $this->security->create_csrf_session();
    }

    public  function validate_add_site_form(){
        if(!$this->security->check_csrf($this->csrf)){
            $this->notice->set_notice("security","یک خطای امنیتی رخ داده است","error") ;
        }
        if($this->form_validate->is_empty($this->inputs["siteName"])){
            $this->notice->set_notice("siteName","نام سایت نمیتواند خالی باشد","error") ;
        }

        if($this->form_validate->is_empty($this->inputs["siteLink"])){
            $this->notice->set_notice("siteLink","آدرس سایت نباید خالی باشد","error") ;
        }

        if( ! $this->form_validate->is_site_url($this->inputs["siteLink"])){
            //$this->notice->set_notice("siteLink","آدرس سایت اشتباه است ( بدون w و http وارد کنید )","error") ;
        }

        if($this->site_already_exist_by_link($this->inputs["siteLink"])){
            $this->notice->set_notice("siteLink","این سایت قبلا ثبت شده است اگر ( مالکیت این سایت به شما منتقل شده با پشتیبانی تماس بگیرید )","error") ;
        }
        if($this->form_validate->is_empty($this->inputs["siteTopic"])){
            $this->notice->set_notice("siteTopic","موضوع سایت نباید خالی باشد","error") ;
        }
        if($this->form_validate->is_empty($this->inputs["sitePriceOneMonth"])){
            $this->notice->set_notice("sitePriceOneMonth","قیمت ماهانه سایت نباید خالی باشد","error") ;
        }
        if(!$this->form_validate->is_numeric($this->inputs["sitePriceOneMonth"])){
            $this->notice->set_notice("sitePriceOneMonth","قیمت ماهانه باید حتما عدد باشد ( اگر از موبایل استفاده میکنید کیبورد را بر روی اعداد بگذارید ) ","error") ;
        }
        if(!$this->form_validate->is_numeric($this->inputs["reportage_price"]) AND !$this->form_validate->is_empty($this->inputs["reportage_price"]  )  ){
            $this->notice->set_notice("reportage_price","قیمت رپورتاژ را باید عددی وارد کنید ","error") ;
        }

        if( $this->form_validate->is_empty($this->inputs["reportage_price"]) AND isset($this->inputs["reportage_check"]) ){
            $this->notice->set_notice("reportage_price","قیمت رپورتاژ را وارد نکرده اید","error") ;
        }



        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;


    }

    public function get_topic_options(){
        $args = array(
            'post_type' => 'mo_bl_sites',
            'taxonomy' => 'category',
            'orderby' => 'name',
            'hide_empty' => false,
            'order'   => 'ASC'
        );

        $cats = get_categories($args);

        foreach($cats as $cat) {
            ?>
            <option value="<?php echo ( $cat->name ) ?>">
                <?php
                echo  $cat->name ;
                ?>
            </option>
            <?php
        }
    }

    /**
     * @param $link
     * true on exist
     * false on not exist
     */
    public function site_already_exist_by_link($link){

        $args = array(
            'post_type'  => 'mo_bl_sites',
            'post_status'  => array("publish","draft"),
            'meta_query' => array(
                'relation' => 'AND',

                array(

                    'key' => 'siteLink',
                    'value' => $link,
                    'compare' => '='
                ),

            )
        );


        $exist = $this->CRUD->check_post_already_exists($args) ;
        if($exist){
            return true ;
        }else{
            return false ;
        }
    }

}