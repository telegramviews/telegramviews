<?php


namespace mo_App\dashboard_pages;


use mo_App\dashboard;

class mo_bl_index extends dashboard
{

}