<?php


namespace mo_App\dashboard_pages;


use mo_App\dashboard;
use mo_App\form_validate;
use mo_App\gatways\mo_bl_zarinpal;
use mo_App\mo_bl_accounting;
use mo_App\mo_bl_cart;
use mo_App\mo_bl_CRUD_post;
use mo_App\mo_bl_email;
use mo_App\mo_bl_gatways;
use mo_App\mo_bl_gatways_interface;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;


class mo_bl_payment_page extends dashboard
{

    private $gatways = object ;
    private $cart = object ;
    private $mysite = object ;
    private $formvalidate = object ;
    public $notice = object ;
    public $security = object ;
    private $accounting = object ;
    private $user = object ;
    private $croud = object ;

    public $verify_price = 0 ;
    public $verify_factor_id = 0 ;
    public $verify_gatway = "" ;
    private $upload_result = array() ;

    public $inputs = array() ;
    public $factor_id = 0 ;
    public $is_reportage = 0 ;
    public function __construct()
    {
        if(  (isset($_GET["refer"]) AND $_GET["refer"]=="reportage")   ){
            $this->is_reportage = 1 ;
         }

        $this->cart = new mo_bl_cart() ;
        $this->mysite = new mo_bl_mysites() ;
        $this->gatways = new mo_bl_gatways() ;
        $this->formvalidate = new form_validate() ;
        $this->notice = new mo_bl_notice() ;
        $this->security = new mo_bl_security() ;
        $this->accounting = new mo_bl_accounting() ;
        $this->croud = new mo_bl_CRUD_post() ;
        $this->user = mo_bl_user::get_instance() ;


        if(isset($_POST["submit_payment"])){

            foreach ($_POST as $key=>$value){
                $this->inputs["$key"] = $this->security->check_input($value) ;
            }


            if($this->form_validation()){

                if(isset($_GET["refer"]) AND $_GET["refer"] == "reportage" ){
                    $type = "reportage" ;
                }else {
                    $type = "backlink" ;
                }
                $this->factor_id = $this->accounting->add_factor($type);


                $sum_of_buyer_price = 0 ;
                foreach ($this->get_cart_table() as $post){
                    // price selected = month
                    if(!$this->is_reportage){
                        $price_selected = $this->inputs["price_radio_$post->ID"] ;
                    }else{
                        $price_selected = $this->inputs["reportage_$post->ID"] ;
                    }



                    $price_temp_seller =$this->get_price_by_month_seller($post->ID,$price_selected) ;
                    if($price_selected == "reportage"){
                        $price_month_selected = 1 ;
                    }else{
                        $price_month_selected = $price_selected ;
                    }
                    $price_per_month_seller = round($price_temp_seller/$price_month_selected) ;


                    $price_temp_admin =$this->get_price_by_month_admin($post->ID,$price_selected) ;
                    $price_per_month_admin = round($price_temp_admin/$price_month_selected) ;
                    $sum_of_buyer_price = $sum_of_buyer_price + $price_temp_admin ;


                    $from_week = $this->inputs["start_time_$post->ID"] ;
                    $start_date = $this->get_start_time($from_week) ;

                    $title = $this->inputs["title_of_back_link_$post->ID"] ;
                    if(! $this->is_reportage){
                        $link = $this->inputs["link_of_back_link_$post->ID"] ;
                    }else{
                        $link = "" ;
                    }


                    if(isset($this->upload_result[$post->ID]["img_url"])){
                        $file_url = $this->upload_result[$post->ID]["img_url"] ;
                    }else{
                        $file_url = "" ;
                    }

                    if($price_selected == "reportage"){
                        $price_selected = 1 ;
                    }

                    $this->accounting->add_factor_item($this->factor_id,$post->ID,$price_per_month_seller,
                        $price_per_month_admin,$price_selected,$start_date,$title,$link,$file_url
                    ,$type);


                }
                mo_bl_email::send($this->user->get_user_email(),"درخواست خرید بک لینک ثبت شد" , "مشتری گرامی درخواست خرید شما ثبت شد و در حال بررسی میباشد ");
                $this->cart->refresh();




                $selected_gatway = $this->inputs["gatway"] ;
                if($selected_gatway == "wallet"){
                    $this->paid_with_wallet($sum_of_buyer_price);
                }else{
                    $selected_gatway = str_replace("\\"."\\","\\",$selected_gatway) ;
                    $selected_gatway= "\\".$selected_gatway ;
                    $selected_gatway = new $selected_gatway() ;
                    $this->run_gatway($selected_gatway,$this->factor_id ,$sum_of_buyer_price,"خرید بک لینک توسط کاربر 
               ".$this->user->get_current_user_display_name()
                        ."به شماره فاکتور" .
                        "$this->factor_id"
                        , $this->user->get_user_mobile() ,$this->user->get_user_email() ) ;
                }



            }


        }


        if(isset($_GET["price"])){
            $this->verify_price = $_GET["price"]  ;
        }
        if(isset($_GET["factor_id"])){
            $this->verify_factor_id = $_GET["factor_id"]  ;
        }
        if(isset($_GET["gatway"])){
            $this->verify_gatway = $_GET["gatway"]  ;

            $selected_gatway = $this->verify_gatway ;
            $selected_gatway = str_replace("\\"."\\","\\",$selected_gatway) ;
            $selected_gatway= "\\".$selected_gatway ;
            $this->verify_gatway = new $selected_gatway() ;
        }

    }

    public function get_sum_of_cart(){
        $sum_of_buyer_price = 0 ;
        foreach ($this->get_cart_table() as $post) {
            // price selected = month
            if (!$this->is_reportage) {
                $price_selected = $this->inputs["price_radio_$post->ID"];
            } else {
                $price_selected = $this->inputs["reportage_$post->ID"];
            }


            $price_temp_seller = $this->get_price_by_month_seller($post->ID, $price_selected);
            if ($price_selected == "reportage") {
                $price_month_selected = 1;
            } else {
                $price_month_selected = $price_selected;
            }
            $price_per_month_seller = round($price_temp_seller / $price_month_selected);


            $price_temp_admin = $this->get_price_by_month_admin($post->ID, $price_selected);
            $price_per_month_admin = round($price_temp_admin / $price_month_selected);
            $sum_of_buyer_price = $sum_of_buyer_price + $price_temp_admin;
        }

        return $sum_of_buyer_price ;
    }

    /*
   * you can edit this function for add gatways
   */
    private function run_gatway(mo_bl_gatways_interface $selected_gatways,$factor_id,$price,$description,$mobile,$email){
        $call_back = new \mo_App\mo_bl_gatways();
        $zarinpal = new \mo_App\gatways\mo_bl_zarinpal() ;
        $call_back->add_gatways($zarinpal);
        $selected_gatways_string = get_class($selected_gatways) ;

        $selected_gatway = $call_back->set_selected_gatway( $selected_gatways ) ;
        $selected_gatway->set_price($price) ;
        $selected_gatway->set_description("$description") ;

        $selected_gatway->set_mobile("$mobile") ;
        $selected_gatway->set_email("$email") ;
        $selected_gatway->set_params(array()) ;

        $selected_gatway->set_callback($call_back->callback_url."&factor_id=$factor_id&gatway=$selected_gatways_string&price=$price") ;
       // var_dump($selected_gatway->data) ;
        $selected_gatway->redirect_to_gatways();
        //$selected_gatway->verify_payment();
        $this->notice = $selected_gatway->notice ;
       // wp_die($call_back->callback_url."&factor_id=$factor_id&gatway=$selected_gatways_string&price=$price");
    }

    public function verify_payment($factor_id,$price,mo_bl_gatways_interface $selected_gatway){


        $call_back = new \mo_App\mo_bl_gatways();
        $zarinpal = new \mo_App\gatways\mo_bl_zarinpal() ;
        $call_back->add_gatways($zarinpal);



        $selected_gatway = $call_back->set_selected_gatway( $selected_gatway ) ;
        $selected_gatway->set_price($price) ;
        $selected_gatway->set_callback($call_back->callback_url."&factor_id=$factor_id") ;
        $varify = $selected_gatway->verify_payment();
        $this->notice = $selected_gatway->notice ;

        if($varify == true){ //TODO afther test it is must be true
            $this->afther_verify_success() ;
        }

    }
    public function paid_with_wallet($sum_of_buyer_price){

        $this->accounting->add_accounting_record($this->user->user_id(),$this->factor_id,"paid_by_wallet",
            $sum_of_buyer_price,0,0,0,0,0);



        $this->accounting->factor_paid($this->factor_id);


        // buyer afther payment

        $items = $this->accounting->get_factor_items_by_factor_id($this->factor_id) ;

        foreach ($items as $item){

            $site_id = $this->accounting->get_site_id_by_item_id($item->ID) ;
            $price_per_month_seller = get_post_meta($item->ID,"price_per_month_seller",true) ;
            $site = get_post($site_id) ;
            $seller_id = $site->post_author ;

            $start_time = get_post_meta($item->ID,"start_date",true) ;
            $number_of_month = get_post_meta($item->ID,"number_of_month",true) ;
            $free_time = 0 ;
            for ($x = 1; $x <= $number_of_month; $x++) {
                $day = 60*60*24 ;
                $month = $day *30 ;
                if($x !=1){
                    $start_time = $start_time + $month * ($x-1) ;
                }
                $free_time = $start_time + $month ;
                //the status dose not important and dosent use in another where
                $this->accounting->add_accounting_record($seller_id,$this->verify_factor_id,"seller_income",
                    0,$price_per_month_seller,$start_time,$free_time,$item->ID,"queue");
            }


        }


        $this->notice->set_notice("success_payment","پردازش های حسابداری با موفقیت انجام شد  ","success") ;

        $this->notice->set_notice("success_payment2","هزینه خرید شما از طریق کیف پول پرداخت شد.","success") ;

    }

    public function afther_verify_success(){


        $this->accounting->add_accounting_record($this->user->user_id(),$this->verify_factor_id,"buy_backlink",
        $this->verify_price,0,0,0,0,0);

        $this->accounting->add_accounting_record($this->user->user_id(),$this->verify_factor_id,"deposit_cash_from_user",
        0,$this->verify_price,0,0,0,0);

        $this->accounting->factor_paid($this->verify_factor_id);


        // buyer afther payment

        $items = $this->accounting->get_factor_items_by_factor_id($this->verify_factor_id) ;

        foreach ($items as $item){
           
            $site_id = $this->accounting->get_site_id_by_item_id($item->ID) ;
            $price_per_month_seller = get_post_meta($item->ID,"price_per_month_seller",true) ;
            $site = get_post($site_id) ;
            $seller_id = $site->post_author ;

            $start_time = get_post_meta($item->ID,"start_date",true) ;
            $number_of_month = get_post_meta($item->ID,"number_of_month",true) ;
            $free_time = 0 ;
            for ($x = 1; $x <= $number_of_month; $x++) {
                $day = 60*60*24 ;
                $month = $day *30 ;
                if($x !=1){
                    $start_time = $start_time + $month * ($x-1) ;
                }
                $free_time = $start_time + $month ;
                //the status dose not important and dosent use in another where
                    $this->accounting->add_accounting_record($seller_id,$this->verify_factor_id,"seller_income",
                        0,$price_per_month_seller,$start_time,$free_time,$item->ID,"queue");
            }


        }


        $this->notice->set_notice("success_payment","پردازش های حسابداری با موفقیت انجام شد  ","success") ;
        if($this->inputs["gatway"] == "wallet"){
            $this->notice->set_notice("success_payment2","هزینه خرید شما از طریق کیف پول پرداخت شد.","success") ;
        }

    }




    private function get_start_time($from_week){
        return time()+ ($from_week * (60*60*24*7)) ;
    }

    private function get_price_by_month_admin($site_id,$month){
        if($month == 1){

            $price_one = get_post_meta($site_id, "sitePriceOneMonth_admin", true);
           return $price_one ;

        }
        if($month == 3){
            $price_three = get_post_meta($site_id, "sitePriceThreeMonth_admin", true);
            return $price_three ;
        }
        if($month == 6){
            $price_six = get_post_meta($site_id, "sitePriceSixMonth_admin", true);
            return $price_six ;
        }
        if($month == "reportage"){
            $price_reportage = get_post_meta($site_id, "reportage_price_admin", true);
            return $price_reportage ;
        }
        return false ;
    }

    private function get_price_by_month_seller($site_id,$month){
        if($month == 1){

            $price_one = get_post_meta($site_id, "sitePriceOneMonth", true);
            return $price_one ;

        }
        if($month == 3){
            $price_three = get_post_meta($site_id, "sitePriceThreeMonth", true);
            return $price_three ;
        }
        if($month == 6){
            $price_six = get_post_meta($site_id, "sitePriceSixMonth", true);
            return $price_six ;
        }
        if($month == "reportage"){
            $price_reportage = get_post_meta($site_id, "reportage_price", true);
            return $price_reportage ;
        }
        return false ;
    }
    public function form_validation(){

        $site_ids = $this->get_sites_ids() ;
        foreach ($site_ids as $id){

            $price_index = "price_radio_$id" ;
            if($this->is_reportage){
                $reportage_price_index = "reportage_$id" ;
                $price_index = $reportage_price_index ;
            }

            $title_index = "title_of_back_link_$id" ;
            $link_index = "link_of_back_link_$id" ;
            $time_index = "start_time_$id" ;



            if( ! isset($_POST["$price_index"]) OR $this->formvalidate->is_empty($_POST["$price_index"])  ){
                $this->notice->set_notice($price_index,"باید برای تمام ردیف ها قیمت را مشخص کنید","error") ;
            }


            if( ! isset($_POST["$title_index"]) OR $this->formvalidate->is_empty($_POST["$title_index"])){
                $this->notice->set_notice($title_index,"یک یا چند تا از عنوان ها مشخص نشده اند ","error") ;
            }

            if( (   ! isset($_POST["$link_index"]) OR $this->formvalidate->is_empty($_POST["$link_index"])   )  AND ! $this->is_reportage ){
                $this->notice->set_notice($link_index,"یک یا چند تا از لینک ها ها مشخص نشده اند ","error") ;
            }

            if(  (  ! isset($_POST["$link_index"]) OR !$this->formvalidate->is_site_url($_POST["$link_index"])  )  AND ! $this->is_reportage ){
                //$this->notice->set_notice($link_index,"یکی یا چندتا از ادرس وب سایت ها اشتباه وارد شده است","error") ;
            }

            if( ! isset($_POST["$time_index"]) OR $this->formvalidate->is_empty($_POST["$time_index"])){
                $this->notice->set_notice($time_index,"خطای امنیتی فیلد تایم با پشتیبان تماس بگیرید ","error") ;
            }

            if( !$this->formvalidate->is_empty($_FILES ["uploadImage_$id"]["name"])  ){
               $upload_result = $this->croud->uplode_file("uploadImage_$id","file_item_id_$id") ;
                if($upload_result["type"] == "error"){

                    $this->notice->set_notice("uploadImage",$this->upload_result["message"],"error") ;
                }else{
                    $this->upload_result[$id] = $upload_result ;
                }
            }

        }

        if($this->inputs["gatway"] == "wallet"){
            $wallet_charge = $this->accounting->get_amount_payable($this->user->user_id()) ;
            $cart_sum = $this->get_sum_of_cart() ;
            if($wallet_charge < $cart_sum){
                $this->notice->set_notice("wallet_cahrge","موجودی کیف پول شما از مجموع سبد خرید شما کمتر است","error") ;
            }
        }

        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;
    }

    public function get_cart_table(){
        $site_ids = $this->get_sites_ids() ;
        if(empty($site_ids)){
            return array() ;
        }

        $sites = $this->mysite->get_sites($site_ids) ;
       return $sites ;
    }

    public function get_sites_ids(){

        $cart_posts =  $this->cart->get_cart_posts() ;
        $site_ids = array() ;
        foreach ($cart_posts as $cart){
            $site_ids[] = get_post_meta($cart->ID,"item_id",true) ;

        }
        return $site_ids ;
    }

    public function get_gatways_option(){
        /** if you want add more gatway at first you must create new class in gatway directory
         * then create a object then add your new object to gatways like this
         *   $zarinpal = new mo_bl_zarinpal() ;
         *   $zarinpal->set_name("درگاه زرین پال")  ;
         *   $this->gatways->add_gatways($zarinpal);
         * **/
        $zarinpal = new mo_bl_zarinpal() ;
        $zarinpal->set_name("درگاه زرین پال")  ;
        $this->gatways->add_gatways($zarinpal);


        $this->gatways->get_gatways_list();
    }

    public function radio_checked($input_name,$thisvalue){


        //this is for reportage
        if($thisvalue == "reportage"){
            echo "checked" ;
            return ;

        }


        // this is for backlink
        if(isset($this->inputs["$input_name"]) && $this->formvalidate->is_numeric($this->inputs["$input_name"]) ){
            $value = $this->inputs["$input_name"]  ;




            if($value == $thisvalue){

                    echo "checked" ;
                    return ;

            }

        }

    }
}