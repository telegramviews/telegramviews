<?php
namespace mo_App\dashboard_pages;


use mo_App\mo_bl_user;
use mo_App\mo_bl_accounting;
use mo_App\mo_bl_CRUD_post;


class mo_bl_bueyr_factor
{
    public $accounting = object ;
    public $crud = object ;
    public $factors = object ;
    private $user = object ;
    public function __construct()
    {
        $this->accounting = new mo_bl_accounting() ;
        $this->crud = $this->accounting->crud_factor ;
        $this->user = mo_bl_user::get_instance() ;
    }

    public function get_factors(){


        $this->factors =  $this->accounting->get_factor_list($this->user->user_id()) ;

        return $this->factors ;
    }

    public function get_factor_price($factor_id){
        return $this->accounting->get_buyer_factor_price_by_id($factor_id) ;

    }
    public function display_pagination(){

        $this->accounting->crud_factor->display_pagination();

    }
}