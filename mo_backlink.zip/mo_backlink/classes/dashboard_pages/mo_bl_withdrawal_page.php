<?php


namespace mo_App\dashboard_pages;


use mo_App\form_validate;
use mo_App\mo_bl_accounting;
use mo_App\mo_bl_CRUD_post;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;

class mo_bl_withdrawal_page
{
    public $notice = object ;
    public $security = object ;
    public $formvalidate = object ;
    public $accounting = object ;
    public $croud = object ;
    public $user = object ;


    public $inputs = array() ;
    public function __construct()
    {
        $this->notice= new mo_bl_notice() ;
        $this->security = new mo_bl_security() ;
        $this->formvalidate = new form_validate() ;
        $this->accounting = new mo_bl_accounting() ;
        $this->croud = new mo_bl_CRUD_post() ;
        $this->user = mo_bl_user::get_instance() ;

        if(isset($_POST["addrequest"])){

            foreach ($_POST as $key=> $value){
                $this->inputs[$key] = $this->security->check_input($value) ;
            }

            if($this->validation()){
               $meta_fields = array(
                    "deposited" => 0 ,
                    "bede" => $this->inputs["amount"] ,
                );
                $this->croud->insert_post(
                    "درخواست برداشت وجه 
                    ".$this->user->get_current_user_display_name() ,
                    "publish" ,
                    $this->user->user_id(),
                    "mo_bl_withdraw",
                    $meta_fields
                ) ;

                $this->notice->set_notice("amount","درخواست شما با موفقیت ثبت شد","success") ;
            }

        }
    }

    public function validation(){
        if( !isset($this->inputs["amount"]) OR $this->formvalidate->is_empty($this->inputs["amount"]) ){
            $this->notice->set_notice("amount","فیلد مقدار باید پر شود ","error") ;
        }
        if(!$this->formvalidate->is_numeric($this->inputs["amount"])){
            $this->notice->set_notice("amount","باید عدد باشد","error") ;
        }

        if($this->inputs["amount"] > $this->accounting->get_amount_payable()  ){
            $this->notice->set_notice("amount","مقدار وارد شده نمیتواند از مقدار قابل برداشت"
                .
             $this->accounting->get_amount_payable()."
             بیشتر باشد","error") ;
        }


        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;

    }



}