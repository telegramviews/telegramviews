<?php


namespace mo_App\dashboard_pages;


use mo_App\mo_bl_CRUD_post;

class account_statement
{

    public $crud = object ;
    public function __construct()
    {
        $this->crud = new mo_bl_CRUD_post() ;
    }


}