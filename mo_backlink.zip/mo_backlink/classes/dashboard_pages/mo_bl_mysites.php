<?php
namespace mo_App\dashboard_pages;


use mo_App\dashboard;
use mo_App\form_validate;
use mo_App\mo_bl_backlink_generator;
use mo_App\mo_bl_cart;
use mo_App\mo_bl_CRUD_post;
use mo_App\mo_bl_security;
use mo_App\mo_bl_user;

class mo_bl_mysites extends dashboard
{
    public $form_validate = object ;
    private $CRUD = object ;
    private $security = object;
    public $user = object ;
    public $cart = object ;

    public $search_term ="" ;
    public $min_price = 0 ;
    public $max_price = 0 ;
    public $order = array(
        "orderby" => "ID",
        "order" => "DESC"
    ) ;
    private $csrf = "" ;
    public $paged = 1 ;
    public $perpage = 10 ;

    public $posts = object ;

    public function __construct()
    {

        $this->paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
        $this->form_validate = new form_validate() ;
        $this->CRUD =  new mo_bl_CRUD_post() ;
        $this->security = new mo_bl_security() ;
        $this->user =  mo_bl_user::get_instance() ;
        $this->cart = new mo_bl_cart() ;





    }

    /**
     * @param int $id
     * @param null $name
     * @param null $orderby its on of them(title,ID,date,modified,or vale of the meta_keys)
     * @param bool $ACS its an orderBy type
     * @param null $link
     * @param null $topic
     * @param int $min_price // 0 if its not have
     * @param int $max_price // 0 if its not have
     * @param string $status
     * @param int $page
     * @param int $per_page it is show how many posts shows in a page
     * @param string $seatch_term this is include post name link and topic
     */


    public function display_script_for_display($site_id){
        $site_link = get_post_meta($site_id,"siteLink",true) ;

        $filegeneratot = new mo_bl_backlink_generator() ;
        $site_link = $filegeneratot->get_site_link_file_name($site_link) ;
        if(file_exists(mo_backliknk_backlink_files_dir."/".$site_link.".js")){
            //include mo_backliknk_backlink_files_dir."/".$_GET["site_title"].".php";
            //this script line most show for slellers sites

          $result= '<script  src="' ;
          $result.= mo_backliknk_backlink_files_url."/".$site_link.".js" ;
          $result.= '"' ;
          $result.='type="text/javascript" ></script>' ;
            $result = str_replace("۴۰۱","401",$result) ;
          return <<<HTML
$result
HTML;

        }else{
            return "اسکریپت فعال نیست به یکی از دلایل زیر : فروشنده تایید شده نیست - بک لینک فعالی وجود ندارد - سایت تایید شده نیست" ;
        }
    }
    public function get_sites($id=0,$seatch_term="",$name=null,$orderby=null,$ACS=false,$link=null,$topic=null,$min_price=0,$max_price=0,$status="all",$user_id=0,$paged=1,$per_page=10,$meta_key=null
    ,$reportage = 0){

        $args = array(

            'post_status'  => array("publish","draft"),

            'meta_query' => array(
                'relation' => 'AND',

            ),
            "orderby" => array()
        );

        if(!$this->form_validate->is_empty($meta_key)){
            $args["meta_key"] = $meta_key ;
        }

        if($status == "all"){
            $args["post_status"] = array("publish","draft","pending") ;
            $args["meta_query"][] =  array(
                'relation' => 'OR',
                array(

                    'key' => 'status',
                    'value' => "pending",
                    'compare' => '='
                ) ,
                array(

                    'key' => 'status',
                    'value' => "publish",
                    'compare' => '='
                ),
                array(

                    'key' => 'status',
                    'value' => "trash",
                    'compare' => '='
                )
            ) ;

        }

        if($reportage == 1){
            $args["meta_query"][]  = array(

                'key' => 'reportage_check',
                'value' => "on",
                'compare' => '='
            ) ;
        }
        if($status != "all"){
            $args["meta_query"][] =  array(

                'key' => 'status',
                'value' => "$status",
                'compare' => '='
            ) ;
        }


        if( !$this->form_validate->is_empty($name)){
            $args["post_title"] = $name ;
        }
        if( !$this->form_validate->is_empty($seatch_term)){
            $args["meta_query"][] =  array(
                'relation' => 'OR',
                array(
                    'key' => 'siteName',
                    'value' => "$seatch_term",
                    'compare' => 'LIKE'
                ) ,
                array(

                    'key' => 'siteLink',
                    'value' => "$seatch_term",
                    'compare' => 'LIKE'
                ) ,
                array(

                    'key' => 'siteTopic',
                    'value' => "$seatch_term",
                    'compare' => 'LIKE'
                ) ,
            ) ;

        }

        if($id != 0 ){
            $args["ID"] = $id ;
        }

        if( $id  != 0 && is_array($id) ){
            $args["post__in"] = $id ;
        }

        if($user_id != 0 ){
            $args["author"] = $user_id ;
        }
        if(is_array($user_id)){
            $args["author__in"] = $user_id ;
        }


        if(!$this->form_validate->is_empty($orderby)){
            $args["orderby"] = $orderby ;
        }


        if($ACS){
            $args["order"] = "ASC" ;
        }elseif(  !$this->form_validate->is_empty($orderby)  ){
            $args["order"] = "DESC" ;
        }

        if( !$this->form_validate->is_empty($link) ){
            $args["meta_query"][] =  array(

                'key' => 'siteLink',
                'value' => "%$link%",
                'compare' => 'LIKE'
            ) ;
        }

        if( !$this->form_validate->is_empty($topic) ){
            $args["meta_query"][] =  array(

                'key' => 'siteTopic',
                'value' => "%$topic%",
                'compare' => 'LIKE'
            ) ;
        }



        if( $min_price != 0 ){
            $args["meta_query"][] =  array(

                'key' => 'sitePriceOneMonth',
                'value' => "$min_price",
                'compare' => '<=',
                'type' => 'NUMERIC'
            ) ;
        }
        if( $max_price != 0 ){
            $args["meta_query"][] =  array(

                'key' => 'sitePriceOneMonth',
                'value' => "$max_price",
                'compare' => '>=',
                'type' => 'NUMERIC'
            ) ;
        }

        $posts = $this->CRUD->get_posts("mo_bl_sites",$paged,$per_page,array(),$args,$args["meta_query"]) ;

       return $posts ;
    }

    //TODO the pagination most create in CRUD class

    public function display_navigation(){
        $this->CRUD->display_pagination();
    }

    public function refresh_cart(){
        $this->cart->refresh();
    }
    private function item_exist_in_cart($item_id){
        return $this->cart->item_exists($item_id) ;
    }
    public function input_checked_for_cart($item_id){
        if($this->item_exist_in_cart($item_id)){
            echo " checked " ;
        }
    }
    public function get_sites_table(){

        $user_id = $this->user->user_id() ;

        $this->get_search_term_params() ;


        $acs = $this->get_set_orderby_params() ;



        $posts = $this->get_sites(0,$this->search_term,"" ,$this->order["orderby"],$acs,null,null,
            $this->min_price,$this->max_price,"all",$user_id,$this->paged,$this->perpage) ;

        return $posts ;

    }

    public function get_search_term_params(){
        if(isset($_GET["search_term"])){
            $this->search_term = $this->security->check_input($_GET["search_term"]) ;


            if($this->form_validate->is_numeric($_GET["min_price"])){
                $this->min_price = $this->security->check_input($_GET["min_price"]) ;
            }
            if($this->form_validate->is_numeric($_GET["max_price"])){
                $this->max_price = $this->security->check_input($_GET["max_price"]) ;
            }
        }
    }

    public function get_set_orderby_params(){
        $meta_key = null ;
        if(isset($_GET["order"])){
            $temp_order = $this->security->check_input($_GET["order"]) ;
            $temp_order = explode("-",$temp_order) ;
            $form_order_by = $temp_order[1] ;
           
            if($form_order_by == "siteName"){
                $this->order["orderby"]  = "title" ; // this is wp_query argument
            }
            if($form_order_by == "link"){
                $this->order["orderby"]  = "siteLink" ; //this is meta key
            }
            if($form_order_by == "topic"){
                $this->order["orderby"]  = "siteTopic" ;
            }
            if($form_order_by == "price"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "sitePriceOneMonth" ;


            }
            if($form_order_by == "status"){
                $this->order["orderby"]  = "status" ;
            }
            if($form_order_by == "da"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "da" ;

            }
            if($form_order_by == "pa"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "pa" ;
                //$this->order["orderby"]  = "pa" ;
            }
            if($form_order_by == "sb"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "sb" ;
               // $this->order["orderby"]  = "sb" ;
            }
            if($form_order_by == "alexa"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "alexa" ;
                //$this->order["orderby"]  = "alexa" ;
            }
            if($form_order_by == "indexedPage"){

                $this->order["orderby"]  = "meta_value_num" ;
                $meta_key  = "indexed_pages" ;
                //$this->order["orderby"]  = "indexed_pages" ;
            }

            $this->order["order"] = $temp_order[0] ;
            if($this->order["order"] == "ACS"){
                $acs = true ;
            }else{
                $acs = false ;
            }
        }else{
            $acs = false ;
        }

        return array(
            "acs"=>$acs ,
            "meta_key"=>$meta_key ,
        ) ;
    }

    public function get_sites_table_for_buyer($reportage=0){


        $this->get_search_term_params() ;
        $result = $this->get_set_orderby_params() ;



        $users_array  = $this->user->get_confirmed_users_list_id();
        $posts = $this->get_sites(0,$this->search_term,"" ,$this->order["orderby"],$result["acs"],null,null,
            $this->min_price,$this->max_price,"publish",$users_array,$this->paged,$this->perpage,$result["meta_key"],$reportage) ;

        return $posts ;

    }



    public function get_status_of_site($siteID){
        $status = get_post_meta($siteID,"status",true) ;
        return $status ;
    }
    public function is_site_active($site_id){
        $status =$this->get_status_of_site($site_id) ;
        if($status == "publish"){
            return true ;
        }
        return false ;
    }

    public function is_site_pending($site_id){
        $status =$this->get_status_of_site($site_id) ;
        if($status == "pending"){
            return true ;
        }


        return false ;
    }


}