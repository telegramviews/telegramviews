<?php
namespace  mo_App ;
class mo_bl_user
{
    private static $instance ;
    public $user = object ;
    public function __construct()
    {
        //$this::get_instance() ;
    }
    public static function  get_instance(){
        if(!self::$instance){

            self::$instance = new self() ;
            self::$instance->user = wp_get_current_user() ;
        }
        return self::$instance ;

    }

    public function get_avatar_url(){
        if( $image = get_user_meta($this->user_id(),"avatar_url",true)){
            
            return $image ;
        }
        return mo_backlink_views_assets."/img/149071.png" ;
    }
    public function get_confirmed_users_list_id(){
        $users = get_users(array(
            'meta_key' => 'user_status',
            'meta_value' => 'publish'
        )) ;
        $result = array() ;
        foreach ($users as $user){
            $result[] = $user->ID ;
        }

        return $result ;
    }

    public function get_current_user_display_name(){
        return $this->user->display_name ;
    }

    public function user_id(){
        return $this->user->ID ;
    }

    public function get_user_status(){
        $userstatus = get_user_meta($this->user_id(),"user_status",true) ;
        return $userstatus ;
    }
    public function get_user_bank_name(){
        return  get_user_meta($this->user_id(),"bankName",true) ;
    }
    public function get_user_bank_account_number(){
        return  get_user_meta($this->user_id(),"bankAccountNumber",true) ;
    }
    public function get_user_bank_account_shaba(){
        return  get_user_meta($this->user_id(),"bankAccountShaba",true) ;
    }

    public function user_update ( $args){
        $user_data = wp_update_user(  $args );

        if ( is_wp_error( $user_data ) ) {
            // There was an error; possibly this user doesn't exist.
            return $user_data ;
        } else {
            // Success!
           return true ;
        }
    }
    public function update_user_meta($array){
        foreach ($array as $key=> $value){

            update_user_meta($this->user_id(),"$key","$value") ;

        }
    }

    public function get_user_mobile(){
        return get_user_meta($this->user_id(),"user_mobile",true) ;
    }
    public function get_user_email(){
        $user = get_userdata($this->user_id()) ;
        $use_email = $user->user_email ;
        return $use_email ;
    }

}