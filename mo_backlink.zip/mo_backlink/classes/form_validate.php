<?php


namespace mo_App;


class form_validate
{
    /**
     * @param $input from form
     */
    public function is_empty ($input){
        if($input == null
        OR $input == ""
        OR $input == NULL
        ){

            return true ;
        }

        return false ;
    }

    public  function is_equal($input1,$input2){
        if($input1 == $input2){
            return true ;
        }

        return false ;
    }

    public function is_mobile ($mobile){
        if(preg_match("/^[0]{1}[9]{1}[0-9]{1}[0-9]{4}[0-9]{4}$/", $mobile)) {
            // $phone is valid
            return true ;
        }

        return false ;
    }

    public function is_email($email){

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
           return false ;
        }
        return true ;
    }

    public function is_site_url($url){
        $is_url =  preg_match('/^[a-z0-9_-]+[\.]*[a-z0-9_]+[\.]*[a-z0-9_]+[\.]{1}[a-z]{2,6}$/i', $url);
        $has_www = preg_match('/^[w]{3}[\.]*[a-z0-9_]+[\.]*[a-z0-9_]+[\.]*[a-z0-9_]+[\.]{1}[a-z]{2,6}$/i', $url);

        if($is_url && !$has_www){
            return true ;
        }
        return false ;
    }
    public function is_numeric($input){
        if(is_numeric($input)){
            return true ;
        }else {
            return false ;
        }
    }

    public function reset_forms($inputs = array()){
        unset($inputs) ;
       return array() ;
    }

    public function check_length($input,$min,$max){

        if( (strlen($input) <= $max) &&  (strlen($input) >= $min)  ){
            return true ;
        }
        return false ;
    }



}