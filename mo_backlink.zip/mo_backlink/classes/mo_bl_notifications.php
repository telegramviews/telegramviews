<?php


namespace mo_App;

/**
 * Class mo_bl_notifications
 * @package mo_App
 * this class use from one custome post type for save and return notifications
 * notification types success const 1,error const 2 , info const 3  , warning const 4
 * notifications have to state read and unread
 */
class mo_bl_notifications
{

}