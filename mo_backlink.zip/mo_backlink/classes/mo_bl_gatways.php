<?php


namespace mo_App;



class mo_bl_gatways
{

    private $dashboard = object ;
    public $notice = object ;

    public $callback_url = "" ;
    private $gatways = array() ;
    private $selected_gatway = array() ;

    public function __construct()
    {
        $this->dashboard = new dashboard() ;


        $this->callback_url = $this->dashboard->get_url("callback_gatways");
    }

    public function add_gatways(object $gatway){
        $this->gatways[] = $gatway ;
    }
    public function get_gatways_list(){
        $list =array() ;
        foreach ($this->gatways as $gatway){
            ?>
        <option value="<?php echo get_class($gatway) ; ?>"><?php echo $gatway->get_name() ; ?></option>
        <?php
        }
    }
    public function set_selected_gatway(object $gatway) {
        $this->selected_gatway = $gatway ;

        return $this->selected_gatway ;
    }


}