<?php


namespace mo_App;


class mo_bl_CRUD_post
{

    private $form_validate ;

    public $post_counts ;
    public $per_page ;

    public function __construct()
    {

        $this->form_validate = new form_validate() ;
    }

    /**
     *
     * @param $post_title
     * @param $post_status
     * @param $user_id
     * @param $post_type
     * @param array $meta_feilds
     */
    public function insert_post($post_title,$post_status,$user_id,$post_type,$meta_feilds = array()){
        $my_post = array(
            'post_title'    => "$post_title",
            'post_status'   => "$post_status",
            'post_author'   => $user_id,
            'post_type' => "$post_type" ,

        );

// Insert the post into the database
        $postid =  wp_insert_post( $my_post );
        if(is_wp_error($postid)){
            wp_die($postid->get_error_message());
            return false ;
        }
        if($postid){
            foreach ($meta_feilds as $key => $value){
                update_post_meta($postid,"$key","$value") ;
            }
        }

        return $postid ;

    }


    /**
     * @param $post_id $post_id == 0 this function will insert
     * @param array $post_array wordpress wp_insert_post array just google wp_insert_post
     * @param array $meta_feilds wordpress meta posts fields
     */
    public function update_post($post_id,$post_array=array(),$meta_feilds = array()){
        $my_post = array() ;
        if(!empty($post_array)){
            foreach ($post_array as $key => $value){
                $my_post["$key"] =  $value ;
            }
        }

        $my_post["ID"] = $post_id ;

// Insert the post into the database
        $postid =  wp_insert_post( $my_post );
        if(is_wp_error($postid)){
            wp_die($postid->get_error_message());
            return false ;
        }
        if($postid){
            foreach ($meta_feilds as $key => $value){
                update_post_meta($postid,"$key","$value") ;
            }
        }

        return $postid ;

    }

    public function delete_post($post_id){
        $posts = wp_delete_post($post_id,true) ;
        if($posts == null OR $posts == false){
            wp_die("پست حذف نشد مشکلی به وجود امده است با برنامه نویس تماس بگیرید");
            return false ;
        }

        return true ;
    }

    /**
     * @param array $args its WP_QUERY parameters
     * false in not exist
     * post array when exist
     */
    public function check_post_already_exists(array $args){
        $posts = get_posts( $args ) ;

        if(empty($posts)){
          return false ;
        }else{
            return $posts ;
        }

    }

    /**
     * @param $post_type required
     * @param int $paged
     * @param int $per_page
     * @param array $orderby_array its like array(
    'city_clause' => 'ASC',
    'state_clause' => 'DESC',
    ),      the key can be the on of main args parameters or meta key parameters
     * @param array $mainargs
     * @param array $meta_args
     */
    public function get_posts($post_type,$paged=1,$per_page=10,$orderby_array = array(), $mainargs = array() , $meta_args = array(
        'relation' => 'AND',

    ) ){

        if(empty($orderby_array)){

        }
        $this->per_page = $per_page ;
        $defultargs = array(
            'post_type'  => $post_type,
            'post_status'  => array("publish","draft"),
            'posts_per_page' => $per_page,
            'paged'=>$paged,
            'meta_query' => $meta_args,
            'orderby' => $orderby_array
        );

        foreach ($mainargs as $key=> $value){
            $defultargs[$key] = $value ;
        }

        $count_args = $defultargs ;

        $count_args["posts_per_page"] = -1 ;



        $posts = get_posts( $defultargs ) ;
        $this->post_counts = get_posts( $count_args ) ;

        return $posts ;





    }

    /*
     * @param $pots this is come from get_posts()
     */
    public  function count_pages($posts){
        $posts =  count($posts) ;

        return floor($posts/$this->per_page)+1 ;
    }

    public function create_pagination ($max,$current){


         echo paginate_links( array(
            'base' => str_replace( 99999, '%#%', esc_url( get_pagenum_link( 99999 ) ) ),
            'format' => '?paged=%#%',
            'current' => max( 1, get_query_var('paged') ),
            'total' => $max,
            'before_page_number' => '<span class=" screen-reader-text mr-2">'."صفحه".' </span>',



        ) );

        //var_dump($array);



    }

    public function display_pagination(){
        $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

        $this->create_pagination($this->count_pages($this->post_counts) ,$paged);
    }



   /*
    * @param $picadress its a url
    * @param $adress it is directory
    * @param
    */

    public function uplode_pic($input_name,$filename,$adreess=null,$picadress=null,$replaceExsitFIle=true){

        if($picadress == null){
            $picadress = get_home_url()."/wp-content/uploads/user_avatars/" ;
        }
        if($adreess == null){
            $adreess = wp_upload_dir()["basedir"]."/user_avatars/" ;
        }

        $allowedExts = array("gif", "jpeg", "jpg", "png","docx");
        $temp = explode(".", $_FILES["$input_name"]["name"]);
        $extension = end($temp);
        if ((
            ($_FILES["$input_name"]["type"] == "image/gif")
                || ($_FILES["$input_name"]["type"] == "image/jpeg")
                || ($_FILES["$input_name"]["type"] == "image/jpg")
                //|| ($_FILES["$input_name"]["type"] == "image/pjpeg")
               // || ($_FILES["$input_name"]["type"] == "image/x-png")
                || ($_FILES["$input_name"]["type"] == "image/png"))
            && ($_FILES["$input_name"]["size"] < 1024000)
            && in_array($extension, $allowedExts)
        ) {
            if ($_FILES["$input_name"]["error"] > 0) {

                return array(
                    "type"=>"error",
                     "message"=>"Error: " . $_FILES["$input_name"]["error"]
                ) ;
            } else {
                //echo "Upload: " . $_FILES["file"]["name"] . "<br>";
                //echo "Type: " . $_FILES["file"]["type"] . "<br>";
                //echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
                //echo "Stored in: " . $_FILES["file"]["tmp_name"];
                if (!file_exists($adreess)) {
                    mkdir($adreess, 0777, true);
                }


                if (file_exists($adreess . $filename.".".$extension) && $replaceExsitFIle != true){
                    //echo $_FILES["file"]["name"] . " already exists. ";
                    return array(
                        "type"=>"error",
                        "message"=>$_FILES["$input_name"]["name"] . " already exists. "
                    ) ;
                }

                if (  file_exists($adreess . $filename.".".$extension) && $replaceExsitFIle == true  ) {
                    unlink($adreess . $filename.".".$extension);
                }

                move_uploaded_file($_FILES["$input_name"]["tmp_name"],
                    $adreess . $filename.".".$extension);
                // echo "Stored in: " . $adreess . $filename;


                return array(
                    "type"=>"success",
                    "message"=>"آپلود با موفقیت انجام شد ",
                    "img_url"=> $picadress . $filename.".".$extension
                ) ;
            }
        }else{
            return array(
                "type"=>"error",
                "message"=>" فرمت فایل باید مجاز باشد jpg,jpeg,jpg,png و همچنین سایز فایل باید زیر یک مگابایت باشد",

            ) ;
        }
    }


    public function uplode_file($input_name,$filename,$adreess=null,$picadress=null,$replaceExsitFIle=true){


        if($picadress == null){
            $picadress = get_home_url()."/wp-content/uploads/reportage_files/" ;
        }
        if($adreess == null){
            $adreess = wp_upload_dir()["basedir"]."/reportage_files/" ;
        }

        $allowedExts = array("docx");
        $temp = explode(".", $_FILES["$input_name"]["name"]);
        $extension = end($temp);
        if (
             ($_FILES["$input_name"]["size"] < 1024000)
            && in_array($extension, $allowedExts)
        ) {
            if ($_FILES["$input_name"]["error"] > 0) {

                return array(
                    "type"=>"error",
                    "message"=>"Error: " . $_FILES["$input_name"]["error"]
                ) ;
            } else {
                //echo "Upload: " . $_FILES["file"]["name"] . "<br>";
                //echo "Type: " . $_FILES["file"]["type"] . "<br>";
                //echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
                //echo "Stored in: " . $_FILES["file"]["tmp_name"];
                if (!file_exists($adreess)) {
                    mkdir($adreess, 0777, true);
                }


                if (file_exists($adreess . $filename.".".$extension) && $replaceExsitFIle != true){
                    //echo $_FILES["file"]["name"] . " already exists. ";
                    return array(
                        "type"=>"error",
                        "message"=>$_FILES["$input_name"]["name"] . " already exists. "
                    ) ;
                }

                if (  file_exists($adreess . $filename.".".$extension) && $replaceExsitFIle == true  ) {
                    unlink($adreess . $filename.".".$extension);
                }

                move_uploaded_file($_FILES["$input_name"]["tmp_name"],
                    $adreess . $filename.".".$extension);
                // echo "Stored in: " . $adreess . $filename;


                return array(
                    "type"=>"success",
                    "message"=>"آپلود با موفقیت انجام شد ",
                    "img_url"=> $picadress . $filename.".".$extension ,
                    "img_name" => $filename
                ) ;
            }
        }else{
            return array(
                "type"=>"error",
                "message"=>" فرمت فایل باید docx باشد",

            ) ;
        }
    }

}