<?php

namespace mo_App ;
class mo_bl_notice
{
    /**
     * @var array the part of messages
     */
    public $notice_messages= array() ;


    /**
     * @param string $name name or code for message
     * @param string $message a text for display to user
     * @param string $type error,success,and etc
     */
    public function set_notice($name,$message,$type){

        $this->notice_messages["$type"][$name] = "$message"  ;
        return true ;
    }


    /**
     * @param string $name name or code for message
     * @param string $type error,success,and etc
     */
    public function get_notice($name,$type){
        if( !empty( $this->notice_messages["$type"][$name])
        AND isset($this->notice_messages["$type"][$name])){

            return $this->notice_messages["$type"][$name]   ;
        }else {
            return false ;
        }

    }



    /**
     * @param string $before it can be html tag like <li>
     * @param string $afther it can be html tag like </li>
     * @param string $type error,success,and etc
     */
    public function get_the_list_of_messages(string $type,string $before, string $afther){

        if(!isset($this->notice_messages[$type])){
            return false ;
        }

        $messages = $this->notice_messages[$type] ;
        $result="" ;
         foreach ($messages as $message){
            $result .= " $before $message $afther " ;
        }

         return $result ;

    }

    public function get_count_notice_by_type($type)
    {
        if(!isset($this->notice_messages[$type])){
            return false ;
        }
        return count($this->notice_messages[$type] ) ;
    }

    public function get_count_notice(){
        if(!isset($this->notice_messages)){
            return false ;
        }
        return count($this->notice_messages ) ;
    }

    /**
     *
     * @param object $notice
     * its just work for error and success
     */
    public function show_notices_bootrtrap(mo_bl_notice $notice){
        $result = "" ;
        if($notice->get_count_notice_by_type("error")){
            $result .= '<div class="alert alert-primary alert-danger" role="alert">' ;
            $result .= $notice->get_the_list_of_messages("error","<li>","</li>") ;
            $result.= '</div>' ;
        }

        if($notice->get_count_notice_by_type("success")){
            $result .= '<div class="alert alert-primary alert-success" role="alert">' ;
            $result .= $notice->get_the_list_of_messages("success","<li>","</li>") ;
            $result.= '</div>' ;
        }

        return $result ;
    }


}