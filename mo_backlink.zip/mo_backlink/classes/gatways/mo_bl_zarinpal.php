<?php

namespace mo_App\gatways ;
use mo_App\mo_bl_gatways_interface;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;

class mo_bl_zarinpal implements mo_bl_gatways_interface
{
    public $notice = object ;
    public $security = object ;
    public $data = array() ;
    public $name = "zarinpal" ;
    private $merchant = "74ca36e1-5e4c-444a-a49f-02bb17a54bc7" ;
   public function __construct()
   {
       $this->notice = new mo_bl_notice() ;
       $this->security = new mo_bl_security() ;

       $this->data = array(
           "merchant_id" => $this->merchant,
           //"amount" => 1000, this is compeleted by setprice
           //"callback_url" => "http://www.yoursite.com/verify.php", set by set callback
          // "description" => "خرید تست",
           //"metadata" => [ "email" => "info@email.com","mobile"=>"09121234567"],
       );

   }

   public function set_params($params = array()){
       foreach ($params as $key=>$value){
           $this->data[$key] = $value  ;
       }
   }
   public function set_callback($callback_url)
   {

       $this->data["callback_url"] = $callback_url."&price=".$this->data["amount"] ;
   }

   public function get_callback(){
       return $this->data["callback_url"] ;
   }

    public function set_price($price)
    {

        $this->data["amount"] = $price ;
    }

    public function set_description($description)
    {

        $this->data["description"] = $description ;
    }

    public function set_email($email)
    {

        $this->data["metadata"]["email"] = $email ;
    }

    public function set_mobile($mobile)
    {

        $this->data["metadata"]["mobile"] = $mobile ;
    }

    public function set_name($name){
        $this->name = $name ;
    }

    /**
     * @param $currency IRT,IRR
     * @return void
     */
    public function set_currency($currency = "IRT"){
        $this->data["currency"] = $currency ;
    }
    public function get_name(){
        return $this->name ;
    }
    public function redirect_to_gatways()  {

        $this->set_currency("IRT"); //set currency

        $jsonData = json_encode($this->data);
        $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/request.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v1');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));

        $result = curl_exec($ch);
        $err = curl_error($ch);
        $result = json_decode($result, true, JSON_PRETTY_PRINT);
        curl_close($ch);



        if ($err) {
            $this->notice->set_notice("crurl_error","$err","error") ;
           // echo "cURL Error #:" . $err;
        } else {
            if (empty($result['errors'])) {
                if ($result['data']['code'] == 100) {



                    $url = 'https://www.zarinpal.com/pg/StartPay/' . $result['data']["authority"] ;

                    $this->security->redirect($url);



                }
            } else {
                $this->notice->set_notice("Error Code",'Error Code: ' . $result['errors']['code'],"error") ;
                $this->notice->set_notice("Error message",'message: ' .  $result['errors']['message'],"error") ;


            }
        }



    }
    public function verify_payment(): bool {

        $Authority = $_GET['Authority'];
        $price = $_GET['price'];
        $data = array("merchant_id" => $this->merchant, "authority" => $Authority, "amount" => $price);
        $jsonData = json_encode($data);
        $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v4');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));

        $result = curl_exec($ch);

        curl_close($ch);
        $err = curl_error($ch); // this is add by me

        $result = json_decode($result, true);
        if ($err) {
            $this->notice->set_notice("curl error","cURL Error #:" . $err,"error") ;
            $res = array(
                "status" => "error" ,
            );
        } else {
            if (isset($result['data']['code']) && $result['data']['code'] == 100) {
                $this->notice->set_notice("Transation success",'Transation success. RefID:' . $result['data']['ref_id'],"success") ;
                $res = array(
                   "status" => "success" ,
               );
            } else {
                $this->notice->set_notice("error transection",'code: ' . $result['errors']['code'],"error") ;
                $this->notice->set_notice("message transection",'message: ' .  $result['errors']['message'],"error") ;
                $res =  array(
                    "status" => "error" ,
                );
                //echo'code: ' . $result['errors']['code'];
                //echo'message: ' .  $result['errors']['message'];
            }
        }

        if($res["status"] == "error"){
            $this->afther_payment_error() ;
            return false ;
        }

        if($res["status"] == "success"){
            $this->afther_payment_success() ;
            return true ;
        }

        return false ;
    }
    public function afther_payment_error() {
        return "" ;
    }
    public function afther_payment_success() {
        return "" ;
    }

}