<?php


namespace mo_App;


class mo_bl_cart
{
    private $crud = object ;
    private $user = object ;
    public function __construct()
    {
        $this->crud  = new mo_bl_CRUD_post() ;
        $this->user = mo_bl_user::get_instance() ;
    }

    /**
     * @param $item_id this is site id from mo_bl_sites
     */
    public function add_item($item_id){
        $time = time() ;
        $user_id = $this->user->user_id() ;

        $title  = "سبد خرید".
           $this->user->get_current_user_display_name() ."
           در روز 
           ".wp_date("Y/m/d",$time) ;
        $meta = array(
          "item_id" => $item_id ,
          "cart_time" => $time ,
        );
        $this->crud->insert_post($title,"publish",$user_id,"mo_bl_sabad",$meta) ;
    }

    public function delete_item($item_id){
        $meta_args =array(
            'relation' => 'AND',
            array(

                'key' => 'item_id',
                'value' => "$item_id",
                'compare' => '='
            )
        )  ;
        $args["author"]  = $this->user->user_id() ;
        $posts = $this->crud->get_posts("mo_bl_sabad",1,-1,array(),$args,$meta_args) ;


        foreach ($posts as $post ){
            echo "item number ".get_post_meta($post->ID,"item_id",true) ;
            $this->crud->delete_post($post->ID) ;
        }
    }

    public function refresh (){
        $time = time() ;
        $yestrday_time = $time - (60*60*24) ;




        $meta_args = array(
            'relation' => 'AND',
            array(
                'key' => 'cart_time',
                'value' => "$yestrday_time",
                'compare' => '<'
            )

        ) ;
        $posts = $this->crud->get_posts("mo_bl_sabad",1,-1,array(),array(),$meta_args) ;
        foreach ($posts as $post ){
            $this->crud->delete_post($post->ID) ;
        }
    }
    public function item_exists($item_id){
        $time = time() ;
        $yestrday_time = $time - (60*60*24) ;
        $meta_args =array(
            'relation' => 'AND',
            array(

                'key' => 'item_id',
                'value' => "$item_id",
                'compare' => '='
            ),
            array(
                'key' => 'cart_time',
                'value' => "$yestrday_time",
                'compare' => '>'
            )
        )  ;
        $args["author"]  = $this->user->user_id() ;
        $posts = $this->crud->get_posts("mo_bl_sabad",1,-1,array(),$args,$meta_args) ;

        if(count($posts) > 0){
            return true ;
        }

        return false ;
    }

    public function get_cart_posts(){
        $time = time() ;
        $yestrday_time = $time - (60*60*24) ;
        $meta_args =array(
            'relation' => 'AND',

            array(
                'key' => 'cart_time',
                'value' => "$yestrday_time",
                'compare' => '>'
            )
        )  ;
        $args["author"]  = $this->user->user_id() ;
        $posts_of_sabad = $this->crud->get_posts("mo_bl_sabad",1,-1,array(),$args,$meta_args) ;

        return $posts_of_sabad ;


    }



}