<?php


namespace mo_App\login_register;


use mo_App\form_validate;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\wordpress_admin_panel\options;

class mo_bl_login
{
    public $notice= object ;
    public $security= object ;
    public $options= object ;
    public $form_validate = object ;

    public $username = "" ;
    public $password="" ;
    private $csrf="" ;
    private $captcha="" ;

    public function __construct($is_register=0)
    {

        $this->notice = new mo_bl_notice() ;
        $this->security = new mo_bl_security() ;
        $this->options = new options() ;
        $this->form_validate = new form_validate() ;
        //if user logged in redirect to dashboard




        if($this->security->check_user_login()){
            wp_redirect($this->options->get_page_url_by_option_name("bl_dashboard_page_id")) ;
            exit();
        }

        if(isset($_POST["submit_login"])){

            $this->username = $this->security->check_input($_POST["username"]) ;
            $this->password = $this->security->check_input($_POST["password"]) ;
            //$this->captcha = $this->security->check_input($_POST["captcha"]) ;
            $this->csrf = $this->security->check_input($_POST["bl_csrf"]) ;
            if($this->validate_login_form()){

                $user = $this->login($this->username,$this->password) ;

                if(! is_wp_error($user)){
                    wp_redirect($this->options->get_page_url_by_option_name("bl_dashboard_page_id")) ;
                    exit();
                }
            }

        }
       if($is_register == 0 ){
           $this->security->create_csrf_session();
       }

    }
    public function validate_login_form(){
        if(!$this->security->check_csrf($this->csrf)){
            $this->notice->set_notice("security","یک خطای امنیتی رخ داده است","error") ;
        }

        if($this->form_validate->is_empty($this->username)){
            $this->notice->set_notice("username","یوزرنیم نمیتواند خالی باشد", "error") ;
        }

        if($this->form_validate->is_empty($this->password)){
            $this->notice->set_notice("password","گذرواژه نمیتواند خالی باشد", "error") ;
        }

        if(! $this->security->validate_google_captcha()){
            $this->notice->set_notice("captcha","اعتبار سنجی کپچا گوگل به درستی انجام نشد","error") ;
        }

        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;
    }

    public function login($username,$password,$remember  = false){
        $creds = array(
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => $remember
        );

        $user = wp_signon( $creds, is_ssl() );

        if(is_wp_error($user)){
            $i =0 ;
            foreach ($user->errors as $key=>$value){
                $this->notice->set_notice("$key","$value[0]","error") ;
                $i++ ;
            }

        }

        if($user instanceof  \WP_User){
            $this->notice->set_notice("login_success","$user->display_name  عزیز با موفقیت  وارد شدید ","success") ;
        }

        return $user ;

    }
}