<?php
namespace mo_App\login_register ;

use mo_App\form_validate;
use mo_App\mo_bl_email;
use mo_App\mo_bl_notice;
use mo_App\mo_bl_security;
use mo_App\wordpress_admin_panel\options;

class mo_bl_register
{
    private $security = object ;
    public $notice = object ;
    private $form_validate = object ;
    public $options = object ;
    public $login = object ;



    public $name= "" ;
    public $mobile= "" ;
    public $email= "" ;
    public $password= "" ;
    public $passwordco= "" ;
    public $captcha_input= "" ;
    public $term= "" ;
    public $csrf = "" ;



    public function __construct()
    {


        $this->security = new mo_bl_security() ;
        $this->notice = new mo_bl_notice() ;
        $this->form_validate = new form_validate() ;
        $this->options = new options() ;
        $this->login = new mo_bl_login(1) ;

        //if user logged in redirect to dashboard
        if($this->security()->check_user_login()){
            wp_redirect($this->options->get_page_url_by_option_name("bl_dashboard_page_id")) ;
            exit();
        }

        if(isset($_POST["submit_reg"])){
            $this->name = $this->security()->check_input($_POST["bl_name"]);
            $this->mobile = $this->security()->check_input($_POST["mobile"]);
            $this->email = $this->security()->check_input($_POST["email"]);
            $this->password = $this->security()->check_input($_POST["password"]);
            $this->passwordco = $this->security()->check_input($_POST["passwordco"]);
            //$this->captcha_input = $this->security()->check_input($_POST["captcha_input"]);
            $this->csrf = $this->security()->check_input($_POST["bl_csrf"]);
            if(isset($_POST["term"])){
                $this->term = $this->security()->check_input($_POST["term"]);
            }else{
                $this->term = false  ;
            }

            if($this->validate_register_form()){
                //regisrer user
                $user_array = array(
                    'user_login' => strtolower( preg_replace( '/\s+/', '', $this->mobile ) ),
                    'user_pass'  => $this->password,
                    'user_email' => $this->email,
                    'first_name' => $this->name,
                    'display_name' => $this->name,
                    'role' => "bl_customer",
                );

                $result     = wp_insert_user( $user_array );
                if(is_wp_error($result)){
                    $i =0 ;

                    foreach ($result->errors as $key=>$vale){
                        if($key == "existing_user_email"){
                            $name = "email" ;
                            $this->notice->set_notice($name,"ایمیل وارد شده قبلا ثبت نام شده است","error") ;
                            continue ;
                        }
                        if($key == "existing_user_login"){
                            $name = "mobile" ;
                            $this->notice->set_notice($name,"این نام کاربری( موبایل ) قبلا ثبت شده است","error") ;
                            continue ;
                        }
                        else{
                            $name = "program$i" ;
                        }

                        $this->notice->set_notice($name,$vale[0],"error") ;
                        $i++ ;
                    }

                }
                if(! is_wp_error($result) AND is_int($result)){
                    update_user_meta($result,"user_status","pending") ;
                    update_user_meta($result,"user_mobile",$this->mobile) ;
                    $this->notice->set_notice("user_create","ثبت نام شما با موفقیت انجام شد ","success") ;
                    mo_bl_email::send(get_userdata($result)->user_email,"ثبت نام در بک لینکو", "کاربر گرامی ثبت نام شما با موفقیت انجام شد ");
                    // login
                    $user = $this->login->login($this->mobile,$this->password) ;
                    //redirect to dashboard pages
                    if(! is_wp_error($user)){
                        wp_redirect($this->options->get_page_url_by_option_name("bl_dashboard_page_id")) ;
                        exit();
                    }
                }
            }



        }

        //this is most be afther the form send
        //becuse csrf session create in login and login include in this file this function had commented
        $this->security->create_csrf_session();

    }


    private function validate_register_form(){
        if(!$this->security->check_csrf($this->csrf)){
            $this->notice->set_notice("security","یک خطای امنیتی رخ داده است","error") ;
        }
        if( $this->form_validate->is_empty($this->name)  ){
            $this->notice->set_notice("name","نام باید وارد شود و نباید خالی باشد","error")  ;
        }
        if($this->form_validate->is_empty($this->mobile)  ){

            $this->notice->set_notice("mobile","موبایل باید وارد شود و نباید خالی باشد","error")  ;
        }
        if($this->check_mobile_exists($this->mobile) ){

            $this->notice->set_notice("mobile","موبایل وارد شده قبلا در سیستم ثبت شده است","error")  ;
        }
        if( ! $this->form_validate->is_mobile($this->mobile)){
            $this->notice->set_notice("mobile","فرمت شماره موبایل وارد شده اشتباه است","error")  ;
        }

        if($this->form_validate->is_empty($this->email)  ){

            $this->notice->set_notice("email","ایمیل باید وارد شود و نباید خالی باشد","error")  ;
        }

        if(! $this->form_validate->is_email($this->email)  ){

            $this->notice->set_notice("email","فرمت ایمیل وارد شده صحیح نمیباشد","error")  ;
        }
        //email existing checks by wordpress core and WP_ERR


        if($this->form_validate->is_empty($this->password)  ){

            $this->notice->set_notice("password","پسورد نباید خالی باشد","error")  ;
        }
        if( ! $this->form_validate->is_equal($this->password , $this->passwordco)){

            $this->notice->set_notice("passwordco","پسورد و تکرار پسورد یکسان نمیباشد","error")  ;
        }

        if( !$this->security()->validate_google_captcha()){

            $this->notice->set_notice("captcha","اعتبار سنجی کپچا گوگل به درستی انجام نشد","error")  ;
        }
        if($this->term != 1){

            $this->notice->set_notice("terms","قبل از ثبت نام باید قوانین و شرایط وب سایت را بپذیرید","error")  ;
        }

        if( $this->notice->get_count_notice_by_type("error") >=1){
            return false ;
        }

        return true ;
    }

    public function check_mobile_exists($mobile){
        $user_query = new \WP_User_Query(
            array(

                'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                    'relation' => 'AND',
                    array(
                        'key'     => 'user_mobile',
                        'value'   => $mobile,
                        'compare' => '==',

                    ),

                ),
            )
        );

      if( ! empty($user_query->get_results() )){
         return true ;
      }else{
          return false ;
      }
    }

    public function security(){
        return $this->security ;
    }




}