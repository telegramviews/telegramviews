<?php


namespace mo_App;




class routing
{
    public $page = "index" ;
    public $host = "" ;

    public function __construct()
    {


        if(isset($_GET["routPage"])){
            $this->page = $_GET["routPage"] ;
        }
    }

    /**
     * @param $path path of the page
     * @param $page the name of the page without .php
     */
    public function page_addres_by_name($path,$page){
       if(file_exists("$path/$page.php" )){
           return "$path/$page.php" ;
       }else{
           wp_die("the page not found 404 in routing class");
       }

    }


}