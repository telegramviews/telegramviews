<html>
<head>
    <!-- Bootstrap CSS -->
    <title><?php echo get_the_title() ; ?></title>
    <link rel="stylesheet" href="<?= mo_backlink_views_assets."/bootstrap-5.0.2-dist/css/bootstrap.rtl.min.css" ; ?>" integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N" crossorigin="anonymous">
    <link rel="stylesheet" href="<?=  mo_backlink_views_assets."/css/style.css" ;  ?>">
    <?
    wp_head();
    ?>
</head>

<body style="direction: rtl">