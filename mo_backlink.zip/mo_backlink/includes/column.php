<?php
function mo_new_modify_user_table( $column ) {
    $column['read/unread'] = 'خوانده شده/نشده';
    $column['account_status'] = 'وضعیت حساب';
    return $column;
}
add_filter( 'manage_users_columns', 'mo_new_modify_user_table' );

function mo_modify_user_table_row( $val, $column_name, $user_id ) {
    switch ($column_name) {
        case 'read/unread' :
            $result = "" ;
            $read_status = get_user_meta($user_id,"new_user",true) ;
            $user_status = get_user_meta($user_id,"user_status",true) ;
            if($read_status == "unread"){
                $result = "<div style='padding-top: 10px'>
<span style='color: white; background-color: #d63638; padding: 10px; margin: 5px;'>(جدید)کاربر در انتظار تایید</span>
</div>

" ;
            }
            if($read_status != "unread"){
                if($user_status == "pending"){
                    $result = "<span style='color: white;background-color: darkorange; padding: 7px;'>در حال انتظار</span>" ;
                }
                if($user_status == "publish"){
                    $result = "<span style='color: white;background-color: green; padding: 7px; '>تایید شده</span>" ;
                }
                if($user_status == "failed"){
                    $result = "<span style='color: white;background-color: red; padding: 7px;'>رد شده</span>" ;
                }
            }
            return $result;
            break ;

        case 'account_status' :
            $result = "" ;
            $accounting  = new \mo_App\mo_bl_accounting() ;

            $result .= "وجه در صف : ";
            $result .= number_format($accounting->get_enqueue_amount($user_id));
            $result .= "</br>" ;

            $result .= "وجه آزاد شده : ";
            $result .= number_format($accounting->get_free_amount($user_id));
            $result .= "</br>" ;

            $result .= "مبلغ قابل برداشت : ";
            $result .= number_format($accounting->get_amount_payable($user_id)) ;
            $result .= "</br>" ;

            $result .= "مبلغ دریافت شده تا کنون : ";
            $result .= number_format($accounting->get_amount_paid($user_id));
            $result .= "</br>" ;

            return $result ;
        default:
    }
    return $val;
}
add_filter( 'manage_users_custom_column', 'mo_modify_user_table_row', 10, 3 );





function add_mo_bl_factor_columns($columns) {


    return array_merge($columns,
        array(

            'paid' => __('وضعیت پرداخت'),
            'type' => __('نوع فاکتور'),



        ));
}
add_filter('manage_mo_bl_factor_posts_columns' , 'add_mo_bl_factor_columns');

function custom_mo_bl_factor_column( $column ) {
    $post_id = get_the_ID() ;
    switch ( $column ) {
        case 'paid':
            $paid = get_post_meta($post_id , "paid", true);
            if($paid ==1){
                echo "<span style='background-color: green; color: white ;'>پرداخت شده</span>" ;
            }else{
                echo "<span style='background-color: red; color: white ;'>کنسل/شده</span>" ;
            }
            break;

        case 'type':
            $type = get_post_meta($post_id , "type", true);
            echo ($type=="reportage") ? "رپورتاژ"  : "بک لینک" ;
            break;





    }
}
add_action( 'manage_mo_bl_factor_posts_custom_column' , 'custom_mo_bl_factor_column' );




function add_mo_bl_withdraw_columns($columns) {


    return array_merge($columns,
        array(

            'bede' => __('مبلغ درخواستی'),
            'deposite' => __('وضعیت پرداخت'),




        ));
}
add_filter('manage_mo_bl_withdraw_posts_columns' , 'add_mo_bl_withdraw_columns');

function custom_mo_bl_withdraw_column( $column ) {
    $post_id = get_the_ID() ;
    switch ( $column ) {
        case 'deposite':
            $paid = get_post_meta($post_id , "paid", true);
            if($paid ==1){
                echo "<span style='background-color: green; color: white ;'>پرداخت شده</span>" ;
            }else{
                echo "<span style='background-color: red; color: white ;'>هنوز پرداخت نشده</span>" ;
            }
            break;

        case 'bede':
            $type = get_post_meta($post_id , "bede", true);
            echo number_format($type);
            break;





    }
}
add_action( 'manage_mo_bl_withdraw_posts_custom_column' , 'custom_mo_bl_withdraw_column' );



function add_mo_bl_accounting_columns($columns) {


    return array_merge($columns,
        array(

            "factor_id" => __('فاکتور') ,
            "type" =>__("نوع"),
            "bede" =>__("بدهکار"),
            "bestan" =>__("بستانکار"),
            "start_date" =>" شروع",
            "free_date" =>"ازاد سازی",
            "factor_item_id" =>"شماره قلم",
           




        ));
}
add_filter('manage_mo_bl_accounting_posts_columns' , 'add_mo_bl_accounting_columns');

function custom_mo_bl_accounting_column( $column ) {
    $post_id = get_the_ID() ;
    switch ( $column ) {
        case 'type':
            $status = get_post_meta($post_id , "type", true);
            if($status == "seller_income"){

                echo "درآمد فروشنده" ;
            }elseif($status == "withdrawal_cash_from_user"){
                echo "پرداخت به کاربر" ;

            }
            elseif($status == "deposit_cash_from_user"){
                echo "دریافت از کاربر" ;

            }elseif($status == "buy_backlink"){
                echo "خرید بک لینک" ;
            }
            break;

        case 'bede':
            $bede = get_post_meta($post_id , "bede", true);
            echo number_format($bede);
            break;
        case 'bestan':
            $bestan = get_post_meta($post_id , "bestan", true);
            echo number_format($bestan);
            break;

        case 'start_date':
            $time = get_post_meta($post_id , "start_date", true);
            if ($time){
                echo wp_date("Y/m/d",$time);
            }else{
                echo "-" ;
            }
            break;

        case 'free_date':
            $time = get_post_meta($post_id , "free_date", true);
            if ($time){
                echo wp_date("Y/m/d",$time);
            }else{
                echo "-" ;
            }

            break;

        case 'factor_id':
            $factor_id = get_post_meta($post_id , "factor_id", true);
           echo $factor_id ;

            break;

        case 'factor_item_id':
            $factor_id = get_post_meta($post_id , "factor_item_id", true);
            echo $factor_id ;

            break;







    }
}
add_action( 'manage_mo_bl_accounting_posts_custom_column' , 'custom_mo_bl_accounting_column' );





function add_mo_bl_factor_item_columns($columns) {

    echo '
    <style>
    #date{
    width: 60px;
    }
    </style>
    ' ;
    return array_merge($columns,
        array(

            'price_buyer' => __('مبلغ(خریدار)'),
            'price_seller' => __('هزینه(فروشنده)'),
            'month' => __('چند ماه'),
            'total_price_buyer' => __('کل خریدار'),
            'total_price_seller' => __('کل فروشنده'),
            'factor_id' => __('شماره فاکتور'),
            'factor_status' => __('پرداخت'),
            'start_date' => __('شروع و پایان'),
            'finish_date' => __('پایان'),
            'item_title' => __('عنوان'),
            'item_link' => __('لینک'),
            'confirm' => __('تایید'),


        ));
}
add_filter('manage_mo_bl_factor_item_posts_columns' , 'add_mo_bl_factor_item_columns');

function custom_mo_bl_factor_item_column( $column ) {
    $post_id = get_the_ID() ;
    switch ( $column ) {
        case 'price_buyer':
            $price = get_post_meta($post_id , "price_per_month_buyer", true);
            echo number_format( round($price,-2) );
            break;

            case 'factor_id':
            $price = get_post_meta($post_id , "factor_id", true);
            echo $price ;
            break;

            case 'factor_status':
            $factor_id = get_post_meta($post_id , "factor_id", true);
            $paid = get_post_meta($factor_id , "paid", true);
            if($paid ==1){
                echo "<span style='background-color: green; color: white ;'>پرداخت شده</span>" ;
            }else{
                echo "<span style='background-color: red; color: white ;'>کنسل/شده</span>" ;
            }

            break;

        case 'price_seller':
            $price = get_post_meta($post_id , "price_per_month_seller", true);
            echo number_format( round($price,-2) );
            break;

        case 'month':
            $price = get_post_meta($post_id , "number_of_month", true);
            echo $price ;
            break;

            case 'item_title':
            $price = get_post_meta($post_id , "title_of_backlink", true);
            echo $price ;
            break;

            case 'item_link':
            $price = get_post_meta($post_id , "link_of_backlink", true);
            $type = get_post_meta($post_id , "type", true);
            $file_url = get_post_meta($post_id , "reportage_file", true);
            if($type == "reportage"){
                echo "<a href='$file_url'>رپورتاژ</a>" ;
            }else{
                echo $price ;
            }

            break;

        case 'total_price_buyer':
            $price = get_post_meta($post_id , "price_per_month_buyer", true);
            $month = get_post_meta($post_id , "number_of_month", true);
            if($month == "reportage"){
                $month = 1 ;
            }
            $price = $price * $month ;
            echo number_format( round($price,-2) );
            break;

        case 'total_price_seller':
            $price = get_post_meta($post_id , "price_per_month_seller", true);
            $month = get_post_meta($post_id , "number_of_month", true);
            if($month == "reportage"){
                $month = 1 ;
            }
            $price = $price * $month ;
            echo number_format( round($price,-2) );
            break;

        case 'start_date':
            $start_date = get_post_meta($post_id , "start_date", true);
            if(function_exists("wpp_jdate")){
                echo wpp_jdate("Y-m-d" , $start_date) ;
            }else{
                echo wp_date("Y-m-d" , $start_date) ;
            }

            break;

        case 'finish_date':
            $start_date = get_post_meta($post_id , "start_date", true);
            $month = get_post_meta($post_id , "number_of_month", true);
            if($month == "reportage"){
                $month = 1 ;
            }
            $finish = $start_date + ( (60*60*24*30)*$month )  ;
            if(function_exists("wpp_jdate")){
                echo wpp_jdate("Y-m-d" , $finish) ;
            }else{
                echo wp_date("Y-m-d" , $finish) ;
            }

            break;


        case 'confirm':
            $confirm = get_post_meta($post_id , "confirm", true);
            if($confirm == 1){
                echo "<span style='background-color: green; color: white ;'>تایید</span>" ;
            }else{
                echo '<button type="button" id="p'.$post_id.'" class="comfirmFactorItem" data-post_id="'.$post_id.'">تایید</button>' ;
            }

            break;



    }
}
add_action( 'manage_mo_bl_factor_item_posts_custom_column' , 'custom_mo_bl_factor_item_column' );



function add_mo_bl_sites_columns($columns) {

    echo '
    <style>
    #date{
    width: 90px;
    }
    </style>
    ' ;
    return array_merge($columns,
        array(

            'status' => __('وضعیت سایت'),
            'sitePriceMonth' => __('قیمت ماهیانه( اعلامی توسط مشتری)'),
            'siteLink' => __('لینک سایت'),



        ));
}
add_filter('manage_mo_bl_sites_posts_columns' , 'add_mo_bl_sites_columns');

function custom_mo_bl_sites_column( $column ) {
    $post_id = get_the_ID() ;
    switch ( $column ) {
        case 'sitePriceMonth':
            $price = get_post_meta($post_id , "sitePriceOneMonth", true);
            echo number_format( round($price,-2) );
            break;

        case 'siteLink':
            $price = get_post_meta($post_id , "siteLink", true);
            echo $price ;
            break;

        case 'status':
            $status = get_post_meta($post_id , "status", true);
            if($status == "publish"){
                echo "<span style='background-color: green; color: white ;'>تایید شده</span>" ;
            }elseif($status == "disable"){
                echo "<span style='background-color: yellow; color: black ;'>غیر فعال شده ( احتمالا توسط اسکریپت )</span>" ;
            }
            elseif($status == "pending"){
                echo "<span style='background-color: yellow; color: black ;'>در حال انتظار برای تایید</span>" ;
            }
            elseif($status == "trash"){
                echo "<span style='background-color: red; color: white ;'>تایید نشده توسط ادمین</span>" ;
            }

            break;




    }
}
add_action( 'manage_mo_bl_sites_posts_custom_column' , 'custom_mo_bl_sites_column' );