<?php
function mo_backlink_init(){
    add_role( 'bl_customer', 'کاربر سیستم بک لینک', get_role( 'subscriber' )->capabilities );
}


function remove_admin_bar() {
    if (!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}

//change custome logo wordpress

function bl_login_logo() { ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php echo get_option("bl_logo_url") ; ?>);
            height:100px;
            width:300px;
            background-size: 300px 100px;
            background-repeat: no-repeat;
            padding-bottom: 10px;
        }
        .language-switcher{
            display: none;
        }
    </style>
<?php }


function bl_login_url( $login_url ) {
    $option = new \mo_App\wordpress_admin_panel\options() ;
    $temlate = get_page_template_slug(get_option("bl_login_page_id")) ;
    if(get_option("bl_login_page_id") AND get_option("bl_login_page_id") != ""   AND $temlate == "login-template.php"){
        $login_url = $option->get_page_url_by_option_name("bl_login_page_id");
    }

    return $login_url;
}

function bl_register_url( $register_url ) {
    $option = new \mo_App\wordpress_admin_panel\options() ;

    $temlate = get_page_template_slug(get_option("bl_register_page_id")) ;
    if(get_option("bl_register_page_id") AND get_option("bl_register_page_id") != "" AND $temlate == "register-template.php"){

        $register_url = $option->get_page_url_by_option_name("bl_register_page_id");
    }

    return $register_url;
}

function mo_modifine_posttypes(){
    $labels = array(
        'name'               => _x( 'mo_bl_sites', '' ),
        'singular_name'      => _x( 'mo_bl_sites', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'سایت های فروشنده گان'
    );
    $args = array(
        'labels'        => $labels,
        'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => true,
        'publicly_queryable' => true,
        'menu_position' => 5,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_sites', $args );




    $labels = array(
        'name'               => _x( 'mo_bl_sabad', '' ),
        'singular_name'      => _x( 'mo_bl_sabad', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'سبد خرید افزونه بک لینک'
    );
    $args = array(
        'labels'        => $labels,
        //'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => false, //TODO afther test its must be false
        'publicly_queryable' => true,
        'menu_position' => 5,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_sabad', $args );







    $labels = array(
        'name'               => _x( 'mo_bl_factor', '' ),
        'singular_name'      => _x( 'mo_bl_factor', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'فاکتور افزونه بک لینک'
    );
    $args = array(
        'labels'        => $labels,
        //'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => true, //TODO afther test its must be false
        'publicly_queryable' => true,
        'menu_position' => 5,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_factor', $args );





    $labels = array(
        'name'               => _x( 'mo_bl_factor_item', '' ),
        'singular_name'      => _x( 'mo_bl_factor_item', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'اقلام فاکتور  بک لینک'
    );
    $args = array(
        'labels'        => $labels,
        //'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => true, //TODO afther test its must be false
        'publicly_queryable' => true,
        'menu_position' => 5,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_factor_item', $args );



    $labels = array(
        'name'               => _x( 'mo_bl_accounting', '' ),
        'singular_name'      => _x( 'mo_bl_accounting', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'رکوردحساب ها  بک لینک'
    );
    $args = array(
        'labels'        => $labels,
        //'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => true, //TODO afther test its must be false
        'publicly_queryable' => true,
        'menu_position' => 5,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_accounting', $args );




    $labels = array(
        'name'               => _x( 'mo_bl_withdraw', '' ),
        'singular_name'      => _x( 'mo_bl_withdraw', '' ),
        'add_new'            => _x( 'جدید', '' ),
        'add_new_item'       => __( 'اضافه کردن' ),
        'edit_item'          => __( 'ویرایش' ),
        'new_item'           => __( 'جدید' ),
        'all_items'          => __( 'همه' ),
        'view_item'          => __( 'مشاهده' ),
        'search_items'       => __( 'جست و جو' ),
        'not_found'          => __( 'موردی پیدا نشد' ),
        'not_found_in_trash' => __( 'موردی در زباله ها پیدا نشد' ),
        'menu_name'          => 'درخواست برداشت وجه'
    );
    $args = array(
        'labels'        => $labels,
        //'taxonomies' => array('category'),
        //'exclude_from_search' => false,
        'has_archive' => true,
        'public' => true, //TODO afther test its must be false
        'publicly_queryable' => true,
        'menu_position' => 6,
        'supports'      => array('title' , 'custom-fields', 'author'),

    );
    register_post_type( 'mo_bl_withdraw', $args );



}

function mo_change_avatar($args, $id_or_email) {
    $avatar_url = get_user_meta($id_or_email, 'avatar_url', true);

    $args['url'] = $avatar_url;

    return $args;
}