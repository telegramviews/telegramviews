/*-- reportage add -------------------------------------------*/
jQuery(document).on('change', '#aceptrepportage', function () {

    /* add class to element */
    if(this.checked){
        jQuery( "#reportageprice").removeClass('d-none');

    }else {
        jQuery( "#reportageprice").addClass('d-none');
    }
   // jQuery("#aceptrepportage").;


    jQuery.ajax({

        url: mehr.ajax_url,
        type: 'post',
        //dataType: 'json',
        data: {
            action: 'changeCaptcha',
            //post_id: jQuery(this).data('post_id'),
            //user_id: jQuery(this).data('user_id')
        },

        success: function (response) {

            jQuery( ".loadingcaptcha").addClass('d-none');
            jQuery( ".change_captcha").removeClass('d-none');
            jQuery( ".captchadiv").html(response);


        },
        error: function (error) {

            alert("یک مشکل به وجود آماده اتصال اینترنتی خود را چک کنید و اگر درست بود با پشتیبان تماس بگیرید")  ;
        }
    });
});

/*-- change captcha -------------------------------------------*/
jQuery(document).on('click', '.change_captcha', function () {

    /* add class to element */

    jQuery(".change_captcha").addClass('d-none');
    jQuery( ".loadingcaptcha").removeClass('d-none');

    jQuery.ajax({

        url: mehr.ajax_url,
        type: 'post',
        //dataType: 'json',
        data: {
            action: 'changeCaptcha',
            //post_id: jQuery(this).data('post_id'),
            //user_id: jQuery(this).data('user_id')
        },

        success: function (response) {

            jQuery( ".loadingcaptcha").addClass('d-none');
            jQuery( ".change_captcha").removeClass('d-none');
            jQuery( ".captchadiv").html(response);


        },
        error: function (error) {

            alert("یک مشکل به وجود آماده اتصال اینترنتی خود را چک کنید و اگر درست بود با پشتیبان تماس بگیرید")  ;
        }
    });
});

/*-- sabad -------------------------------------------*/
function cart_toggle() {


    if(this.checked) {
        //add item to sabad

        var actionName = "moBlAddItemToCart" ;
    }else{
        //delete item from sabad
        var actionName = "moBlDeleteItemFromCart" ;
    }

    var classes = (jQuery(this).attr("class")) ;

    jQuery.ajax({
        url: mehr.ajax_url,
        type: 'post',
        //dataType: 'json',
        data: {
            action: actionName,
            site_id: jQuery(this).val(),

        },

        success: function (response) {

            console.log(response) ;
            if(classes.search("cart_delete") != -1){
                location.reload() ;
            }


        },
        error: function (error) {

            alert("یک مشکل به وجود آماده اتصال اینترنتی خود را چک کنید و اگر درست بود با پشتیبان تماس بگیرید")  ;
        }
    });
}

jQuery(document).on('change', '.cart_check',cart_toggle);
jQuery(document).on('click', '.cart_delete', cart_toggle);


/*-- payment page -------------------------------------------*/

function getCheckedBoxes(chkboxName) {
    var checkboxes = document.getElementsByClassName(chkboxName);
    var checkboxesChecked = [];
    // loop over them all
    for (var i=0; i<checkboxes.length; i++) {
        // And stick the checked ones onto an array...
        if (checkboxes[i].checked) {
            checkboxesChecked.push(checkboxes[i]);
        }
    }
    // Return the array if it is non-empty, or null
    return checkboxesChecked.length > 0 ? checkboxesChecked : null;
}
function set_sum_of_cart_checks(){
    //add item to sabad

    var checkedBoxes = getCheckedBoxes("pricRadio") ;

    var i = 0 ;
    var  plus = 0 ;
    if(checkedBoxes != null){
        Object.values(checkedBoxes).forEach(val => {
            var number =  val.dataset.price ;
            number = parseInt(number) ;
            plus = parseInt(plus) ;
            plus = plus + number;

            i++ ;
        });
    }
    var totalpriceelement = jQuery(".total-price").text(plus) ;

}
jQuery(document).on('change', '.pricRadio', function () {
    set_sum_of_cart_checks() ;
});
jQuery(document).ready( function () {
    set_sum_of_cart_checks() ;
});

/*----------start confirm item ----------------*/

jQuery(document).on('click', '.comfirmFactorItem', function () {
    alert("sam alik")
    jQuery.ajax({

        url: mehr.ajax_url,
        type: 'post',
        //dataType: 'json',
        data: {
            action: 'confirmFactorItem',
            post_id: jQuery(this).data('post_id'),
            //user_id: jQuery(this).data('user_id')
        },

        success: function (response) {
            alert("#p"+response)

            jQuery( "#p"+response).html("تایید شده");


        },
        error: function (error) {

            alert("یک مشکل به وجود آماده اتصال اینترنتی خود را چک کنید و اگر درست بود با پشتیبان تماس بگیرید")  ;
        }
    });
});

/*----------end confirm item ----------------*/