<?php
// Ajax functions

//--------ecquee ajax script -------------------------------
    $res = wp_enqueue_script( 'mo-bl-ajax', mo_backliknk_includes_url . '/ajax/mo-bl-ajax-scripts.js' , array('jquery'), '4.0', true );

    wp_localize_script(
        "mo-bl-ajax",
        "mehr",
        [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
        ]
    );
//---------end enqueue------------------------------------------------


add_action( 'wp_ajax_changeCaptcha',        'mo_bl_changeCaptcha' );
add_action( 'wp_ajax_nopriv_changeCaptcha', 'mo_bl_changeCaptcha' );
function mo_bl_changeCaptcha() {

   $security = new \mo_App\mo_bl_security() ;


    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {

        $security->create_captcha_img(array("captcha_class"));
        echo "
         <i class=\"change_captcha fas fa-refresh fa-lg me-3 fa-fw\"></i>
                                        <i class=\"loadingcaptcha d-none fas fa-loading fa-lg me-3 fa-fw\"></i>" ;
        exit();

    } else { wp_redirect( home_url( ) ); exit(); }
}


add_action( 'wp_ajax_confirmFactorItem',        'mo_bl_confirmFactorItem' );
add_action( 'wp_ajax_nopriv_confirmFactorItem', 'mo_bl_confirmFactorItem' );
function mo_bl_confirmFactorItem() {




    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
        $post_id = $_POST["post_id"] ;
        $resilt = update_post_meta($post_id,"confirm",1) ;
        echo $post_id ;
        exit();

    } else { wp_redirect( home_url( ) ); exit(); }
}

//----------cart start------------------
add_action( 'wp_ajax_moBlAddItemToCart',        'moBlAddItemToCart' );
add_action( 'wp_ajax_nopriv_moBlAddItemToCart', 'moBlAddItemToCart' );
function moBlAddItemToCart() {

    $cart_object = new \mo_App\mo_bl_cart() ;


    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {

        $post_id = $_REQUEST["site_id"];
        $cart_object->add_item($post_id);
        echo "به سبد خرید اضافه شد" ;
        exit();

    } else { wp_redirect( home_url( ) ); exit(); }
}


add_action( 'wp_ajax_moBlDeleteItemFromCart',        'moBlDeleteItemFromCart' );
add_action( 'wp_ajax_nopriv_moBlDeleteItemFromCart', 'moBlDeleteItemFromCart' );
function moBlDeleteItemFromCart() {


    $cart_object = new \mo_App\mo_bl_cart() ;

    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {

        $post_id = $_REQUEST["site_id"];
        $cart_object->delete_item($post_id);
        echo "از سبد خرید با موفقیت حذف شد" ;
        exit();
        exit();

    } else { wp_redirect( home_url( ) ); exit(); }
}

//-------------cart end ------------------------------