<?php
// this to lines most be on the cronjob
$back_link_generator = new \mo_App\mo_bl_backlink_generator() ; //just for test this is must execute by cronjob
$result = $back_link_generator->generate_back_link_files() ; //just for test this is must execute by cronjob
$result = $back_link_generator->check_script_exist_in_seller_site() ; //just for test this is must execute by cronjob with another generator file
?>
<body>

<?php
echo $result ;
?>
</body>
<?php

