<?php
$route = new \mo_App\routing() ;
include_once  ( mo_backlink_views."/dashboard/pages/index.php" );