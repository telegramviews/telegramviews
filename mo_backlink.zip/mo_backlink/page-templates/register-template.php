<?php
/* Template Name: register template */
include mo_backlink_dirpath."/views/login-register/register.php" ;